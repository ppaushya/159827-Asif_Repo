package registration;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {
	
	private WebDriver driver;
	private WebElement element;
	
	@Before
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\selenuim\\chromedriver.exe");
		
		//Initialize Chrome Drivfer
		driver=new ChromeDriver();
		
	}
	
	@Given("^open registration page$")
	public void open_registration_page() throws Throwable {
	    
		driver.get("C:\\Users\\muasif\\Desktop\\ConferenceRegistartion.html");
		//driver.get(".\\src\\main\\ConferenceRegistartion.html");
		Thread.sleep(2000);
	}

	@When("^title is Conference Registration$")
	public void title_is_Conference_Registration() throws Throwable {
	   
		//if(!driver.getTitle().equals("Conference Registration"))
	    	//driver.quit();
		
		
		assertEquals("Conference Registartion", driver.getTitle());
	}

	@When("^heading is Step (\\d+): Personal Details$")
	public void heading_is_Step_Personal_Details(int arg1) throws Throwable {
	    
		/*List<WebElement> elements=driver.findElements(By.tagName("h4"));
		
		for(WebElement element1:elements)
		System.out.println(element1);*/
			
	}

	@When("^valid details$")
	public void valid_details() throws Throwable {
	    
		driver.findElement(By.name("txtFN")).sendKeys("Mohan");
		driver.findElement(By.name("txtLN")).sendKeys("Lal");
		driver.findElement(By.name("Email")).sendKeys("mo@cg.com");
		driver.findElement(By.name("Phone")).sendKeys("7894563211");
		
		
		Select select=new Select(driver.findElement(By.name("size")));
		select.selectByValue("two");	
		
		driver.findElement(By.name("Address")).sendKeys("address1");
		driver.findElement(By.name("Address2")).sendKeys("Address2");
		
		select=new Select(driver.findElement(By.name("city")));
		select.selectByValue("Chennai");
		
		select=new Select(driver.findElement(By.name("state")));
		select.selectByValue("Tamilnadu");
		
		driver.findElement(By.name("memberStatus")).click();
		
		
		Thread.sleep(5000);
		
	}

	@When("^click next button$")
	public void click_next_button() throws Throwable {
	   
		Thread.sleep(2000);
		driver.findElement(By.tagName("a")).click();
		//Thread.sleep(2000);
		
	}

	

//	@Then("^Alert box displays \"(.*?)\"$")
//	public void alert_box_displays(String arg1) throws Throwable {
//		
//		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
//		Alert alert=driver.switchTo().alert();
//		alert.accept();
//		driver.navigate().to("C:\\Users\\muasif\\Desktop\\PaymentDetails.html");
//	}
	
	@Then("^Navigate to Payment Details page$")
	public void navigate_to_Payment_Details_page() throws Throwable {
		Alert alert=driver.switchTo().alert();
		Thread.sleep(1000);
		alert.accept();
		
		driver.navigate().to("C:\\Users\\muasif\\Desktop\\PaymentDetails.html");
		Thread.sleep(1000);
		
		
	}
	
	@Given("^Payment Details page$")
	public void payment_Details_page() throws Throwable {
		driver.get("C:\\Users\\muasif\\Desktop\\PaymentDetails.html");
	}

	@When("^payment details entered$")
	public void payment_details_entered() throws Throwable {
	   
		driver.findElement(By.name("txtFN")).sendKeys("Mohan");
		driver.findElement(By.name("debit")).sendKeys("456321");
		driver.findElement(By.name("cvv")).sendKeys("456");
		driver.findElement(By.name("month")).sendKeys("july");
		driver.findElement(By.name("year")).sendKeys("2022");
		
		Thread.sleep(1000);
	}

	@When("^Click Register button$")
	public void click_Register_button() throws Throwable {
	    element=driver.findElement(By.id("btnPayment"));
	    element.click();
		
	}

	@Then("^Alert box displays Registration Successful$")
	public void alert_box_displays_Registration_Successful() throws Throwable {
		Alert alert=driver.switchTo().alert();
		alert.accept();
		
		Thread.sleep(1000);
	}
	
	@After
	public void closing() {
		driver.quit();
	}

}
