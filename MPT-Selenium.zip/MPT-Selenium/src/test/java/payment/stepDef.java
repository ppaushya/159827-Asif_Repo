package payment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {
	
	private WebDriver driver;
	private WebElement element;
	
	@Before
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\selenuim\\chromedriver.exe");
		
		//Initialize Chrome Drivfer
		driver=new ChromeDriver();
		
	}
	
	@Given("^Payment Details page$")
	public void payment_Details_page() throws Throwable {
		
		driver.get("C:\\Users\\muasif\\Desktop\\ConferenceRegistartion.html");
	}

	@When("^payment details entered$")
	public void payment_details_entered() throws Throwable {
	    
	}

	@When("^Click Register button$")
	public void click_Register_button() throws Throwable {
	    
	}

	@Then("^Alert box displays Registration Successful$")
	public void alert_box_displays_Registration_Successful() throws Throwable {
	   
	}

	
	@After
	public void closing() {
		driver.close();
	}

}
