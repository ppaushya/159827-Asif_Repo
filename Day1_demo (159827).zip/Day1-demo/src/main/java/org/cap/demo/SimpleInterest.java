package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {

	double principle;
	float year;
	float rateOfInterest;
	
	public void getData()
	{
	/*	principle=4000;
		year=3.3f;
		rateOfInterest=0.0665f;		
	*/
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter Principle:");
		principle=scanner.nextDouble();
		
		System.out.println("Enter Years:");
		year=scanner.nextFloat();
		
		System.out.println("Enter rate of Interest");
		rateOfInterest=scanner.nextFloat();
		
		scanner.close();
		
	}
	
	public double calcualteInterest()
	{
		return principle*year*rateOfInterest;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
