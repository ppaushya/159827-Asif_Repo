package org.cap.demo;

import java.util.Scanner;

public class Student_demo {

	String name;
	int marks1,marks2,marks3;
	
	public void getStudent()
	{
Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter Name:");
		name=scanner.nextLine();
		
		System.out.println("Enter Marks1:");
		marks1=scanner.nextInt();
		
		System.out.println("Enter Marks2:");
		marks2=scanner.nextInt();
		
		System.out.println("Enter Marks3:");
		marks3=scanner.nextInt();
		
		
		
		scanner.close();
	}
	public int findScore()
	{
		return marks1+marks2+marks3;
	}
	
	public float findAverage()
	{
		float avg;
		avg=findScore()/3;
		return avg;
	}
	
	public void printStudent()
	{
		System.out.println("Name:"+name);
		
		
		System.out.println("Marks1:"+marks1);
		
		
		System.out.println("Marks2:"+marks2);
		
		
		System.out.println("Marks3:"+marks3);
		
		
		System.out.println("Average:"+findAverage());
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student_demo obj=new Student_demo();
		
		obj.getStudent();
		obj.printStudent();
	}

}
