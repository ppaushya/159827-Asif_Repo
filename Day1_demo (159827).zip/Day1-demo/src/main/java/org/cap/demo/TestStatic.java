package org.cap.demo;

public class TestStatic {

	String name;
	static int count;
	final float pi=3.24f;	//Final variable
	
	public static void show()
	{
		System.out.println("Count:"+count);
		//System.out.println("Name:"+name); //cant use because non static cant be used inside static method
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TestStatic obj=new TestStatic();
	
		
		obj.name="Tom";
		obj.count=10;
		//TestStatic.count=11;
		obj.show();
		System.out.println(obj.name);
		System.out.println(obj.count);
		
		TestStatic obj1=new TestStatic();
		
		obj1.count=1000;
		obj.name="Donald Duck";
		obj.show();
	}

}
