package org.cap.demo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SimpleInterest interest=new SimpleInterest();
		
		interest.getData();
		
		double simpleinter=interest.calcualteInterest();
		
		//Scanner scanner=new Scanner(System.in);
		
		System.out.println("Calculate:"+simpleinter);
		
	}

}
