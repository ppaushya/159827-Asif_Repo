package org.cap.demo;

import java.util.Scanner;

public class Employee {

	int empId;
	String empName;
	int age;
	boolean isPermanent;
	String gender;
	String address;
	
	public void getEmployee()
	{
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter Employee Id:");
		empId=scanner.nextInt();
		
		System.out.println("Enter Name:");
		empName=scanner.next();
		
		System.out.println("Enter Age:");
		age=scanner.nextInt();
		
		System.out.println("Is Permanent:");
		isPermanent=scanner.nextBoolean();
		
		System.out.println("Gender:");
		gender=scanner.next();
		
		System.out.println("Addess:");
		address=scanner.next();
		
		scanner.close();
	}
	
	
	public void printEmployee()
	{
		System.out.println("Employee Id:"+empId);
		System.out.println("Name:"+empName);
		System.out.println("Age:"+age);
		System.out.println("Is Permanent:"+isPermanent);
		System.out.println("Gender:"+gender);
		System.out.println("Addess:"+address);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Employee emps=new Employee();
			
			emps.getEmployee();
			emps.printEmployee();
	}

}
