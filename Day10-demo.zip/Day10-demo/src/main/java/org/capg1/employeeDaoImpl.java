package org.capg1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class employeeDaoImpl implements  employeeDao{

	@Override
	public void createEmployee(employee emp) {

		String sql="insert into employee values(?,?,?,?)";
		try(Connection connection=getDbConnection())
		{
		
		PreparedStatement statement=connection.prepareStatement(sql);
		
		statement.setInt(1, emp.getId());
		statement.setString(2, emp.getName());
		statement.setDouble(3, emp.getSalary());
		statement.setDate(4, java.sql.Date.valueOf(emp.getDoj()));
		
		statement.executeUpdate(sql);
		
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

	private Connection getDbConnection() {
		Connection connection;

		try
		{
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			Class.forName("com.mysql.jdbc.Driver");
			return connection;
		}catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
