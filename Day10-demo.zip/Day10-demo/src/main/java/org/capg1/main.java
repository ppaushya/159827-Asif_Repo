package org.capg1;

import java.time.LocalDate;

public class main {

	public static void main(String[] args) {
		

		employee emp=new employee(100,"abc",2569,LocalDate.now());
		employeeDaoImpl obj=new employeeDaoImpl();
		
		obj.createEmployee(emp);
		
		
		
	}

}
