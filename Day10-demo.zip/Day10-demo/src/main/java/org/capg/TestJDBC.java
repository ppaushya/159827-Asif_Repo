package org.capg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestJDBC {

	public static void main(String[] args) {

	//	Connection connection=null;
		
//load driver class
		try(Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123")) 
		{
			Class.forName("com.mysql.jdbc.Driver");
			//connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			Statement statement=connection.createStatement();
			
			String sql1="drop table employee";
			statement.execute(sql1);
			
			
			String sql="create table employee(empId int primary key,Fname varchar(20),Lname varchar(20) not null,"
					+ "salary numeric(8,2),doj Date)";
			
			
			
			boolean flag=statement.execute(sql);
			
			if(!flag)
				System.out.println("Table created Successfully");
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Since connection declare in try so no need for finally
		/*finally{try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}*/
	}

}
