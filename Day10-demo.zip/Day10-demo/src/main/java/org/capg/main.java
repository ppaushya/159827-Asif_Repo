package org.capg;

public class main {

	public static void main(String[] args) {
	
		Sender<String,Integer> str=new Sender();
		str.setMessages("Hello World Again");
		System.out.println(str.getMessages());
		
		str.setMessage2(12);
		
		System.out.println(str.getMessage2()+2);
		
		
		

	}

}
