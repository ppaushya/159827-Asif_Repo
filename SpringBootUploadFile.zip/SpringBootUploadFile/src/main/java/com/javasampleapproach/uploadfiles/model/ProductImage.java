package com.javasampleapproach.uploadfiles.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="productImage")
public class ProductImage {
	
	@Id
	@Column(name="imageId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int imageId;
	
//	@Column(name="productId")
	
	private String imageUrl;
	private String imageStatus;
	
	public int getImageId() {
		return imageId;
	}
	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getImageStatus() {
		return imageStatus;
	}
	public void setImageStatus(String imageStatus) {
		this.imageStatus = imageStatus;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getString() {
		return imageStatus;
	}
	public void setString(String imageStatus) {
		this.imageStatus = imageStatus;
	}
	@Override
	public String toString() {
		return "ProductImage [imageId=" + imageId + ", imageUrl=" + imageUrl + ", imageStatus="
				+ imageStatus + "]";
	}
	public ProductImage(int imageId, String imageUrl, String imageStatus) {
		super();
		this.imageId = imageId;
	
		this.imageUrl = imageUrl;
		this.imageStatus = imageStatus;
	}
	public ProductImage() {
		super();
	}
}