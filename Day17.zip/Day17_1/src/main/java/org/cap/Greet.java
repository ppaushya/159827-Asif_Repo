package org.cap;

import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Greet extends SimpleTagSupport{
	
	
	private String user;
	private String color;

	public void setUser(String user) {
		this.user = user;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out= getJspContext().getOut();
		//StringWriter write=new StringWriter();
		//getJspBody().invoke(write);
		
		LocalTime now = LocalTime.now();
		LocalTime limit1 = LocalTime.parse( "01:00" );
		LocalTime limit2 = LocalTime.parse( "10:00" );
		LocalTime limit3 = LocalTime.parse( "14:00" );
	
		
		Boolean isLate = now.isAfter( limit1 );

		if(now.isAfter(limit1) && now.isBefore(limit2))
			out.println("<h3>good morning! </h3>");
		
		if(now.isAfter(limit2) && now.isBefore(limit3))
			out.println("<h3>good Afternoon! </h3>");
		
		if(now.isAfter(limit3))
			out.println("<h3>Good Evening!</h3>");
		
		
	}
	
	
	

}
