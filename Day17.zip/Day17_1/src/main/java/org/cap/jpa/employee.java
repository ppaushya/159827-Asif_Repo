package org.cap.jpa;

public class employee {
	
	

}
