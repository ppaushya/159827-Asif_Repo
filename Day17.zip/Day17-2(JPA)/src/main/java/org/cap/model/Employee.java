package org.cap.model;

import java.beans.Transient;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity(name="employee_Info")

public class Employee {
	@SequenceGenerator(name="gen", initialValue=100)
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="gen")
	private int empId;
	
	@Column(name="Fname")
	private String name;
	
	@Basic
	private double salary;
	
	@Temporal(value=TemporalType.DATE)
	private Date doj;

	@javax.persistence.Transient
	private String password;
	
	
	
	
	
	public Employee(String name, double salary, Date doj, String password) {
		super();
		this.name = name;
		this.salary = salary;
		this.doj = doj;
		this.password = password;
	}
	public Employee(int empId, String name, double salary, Date doj, String password) {
		super();
		this.empId = empId;
		this.name = name;
		this.salary = salary;
		this.doj = doj;
		this.password = password;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", salary=" + salary + "]";
	}
	public Employee(int empId, String name, double salary) {
		super();
		this.empId = empId;
		this.name = name;
		this.salary = salary;
	}
	public Employee()
	{
		
	}
}
