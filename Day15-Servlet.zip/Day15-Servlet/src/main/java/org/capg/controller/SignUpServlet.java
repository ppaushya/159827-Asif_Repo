package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ILoginService login=new LoginServiceImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//Capture the data from View
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		
		String dateOfbirth=request.getParameter("dateOfbirth");
		//dateOfbirth is in format yyyy-mm-dd
		
		int year=Integer.parseInt(dateOfbirth.substring(0,4));
		int month=Integer.parseInt(dateOfbirth.substring(5, 7));
		int date=Integer.parseInt(dateOfbirth.substring(8,10));
		
		
		LocalDate doj=LocalDate.of(year, month, date);
		
	//	String address1=request.getParameter()
		
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		String password=request.getParameter("custPwd");
		String confirmPassword=request.getParameter("confimrCustPwd");
		
		//Password match with confirm password or not
		if(password.equals(confirmPassword))
		{
		
		//Convert the input into Model
		Customer customer=new Customer();
		
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setDateOfBirth(doj);
		customer.setEmailId(email);
		customer.setMobile(mobile);
	
		customer.setPassword(password);
		
		
		System.out.println(customer);
		
		
			//response.sendRedirect("success");
		
	
	
		}
		else
			response.sendRedirect("index.html");
					
			
	}

}
