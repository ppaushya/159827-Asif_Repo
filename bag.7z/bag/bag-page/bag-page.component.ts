import { Component, OnInit } from '@angular/core';
import { BagService } from './bag-page.service';
import { Product } from '../../data/meta';
import { DataService } from '../../data/data.service';

@Component({
  selector: 'app-bag-page',
  templateUrl: './bag-page.component.html',
  styleUrls: ['./bag-page.component.scss']
})
export class BagPageComponent implements OnInit {

  constructor(private bagService:BagService,private data:DataService) { }

 // items:number=5;
 
  items:number=1;
  //this.bagService.getNumberOfProduct()
  quantity:number;
  products : Product[];
  cartProducts:Product;
  total:number;


  ngOnInit() {

    this.products=this.data.products;
    
  }

  getQuantity():number{
    return this.quantity;
  }

  setQuantity(quantity:number){

    this.quantity=quantity;
  }

  addToCart(product:Product){

    this.cartProducts=product;
    this.items++;
  }
  
  

  




}
