import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { DataService } from "../../data/data.service";
import { Observable } from "rxjs";

@Injectable()
export class BagService {

 //bagUrl:string="";
 


constructor(private _http:HttpClient, private data: DataService){}

getNumberOfProduct():number{
    //Observable<number>{

    //return this._http.get<Number>(this.bagUrl);
    return 50;

}

} 