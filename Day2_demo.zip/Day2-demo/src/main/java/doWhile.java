import java.util.Scanner;

public class doWhile {

	String name;
	int productid;
	int quantity;
	float price;
	int discount;
	int tax;
	
	public void getProductDetail()
	{
		Scanner scanner=new Scanner(System.in);
		
		System.out.print("Enter the name:");
		name=scanner.next();
		
		System.out.print("Enter the Product Id:");
		productid=scanner.nextInt();
		
		System.out.print("Enter the Quantity:");
		quantity=scanner.nextInt();
		
		System.out.print("Enter the Price:");
		price=scanner.nextFloat();
		
		System.out.print("Enter the Discount:");
		discount=scanner.nextInt();
		
		scanner.close();
		
	}
	
	public float calculateDiscount()
	{
		return price*quantity*discount/100;
	}
	
	public float calculateTax()
	{
		if(discount>90)
			tax=1;
		else if(discount>80 && discount<90)
			tax=12;
		else if(discount>70 && discount<80)
			tax=20;
		else if(discount>60 && discount<70)
			tax=25;
		else if(discount<60)
			tax=40;
		
		return tax*quantity*price/100;
	}
	
	public void calculateFinalPrice()
	{
		float Fprice=(price*quantity)+calculateTax()-calculateDiscount();
		
		System.out.println();
		System.out.println("Name:"+name);
		System.out.println("Quantity:"+quantity);
		System.out.println("Price per piece:"+price);
		System.out.println("Discount:"+calculateDiscount());
		System.out.println("Tax:"+calculateTax());
		System.out.println("Final Price:"+Fprice);
	}
	public static void main(String[] args) {
		// Do-While Loop
		char ch='n';
		Scanner scan=new Scanner(System.in);
		
		do
		{	
		
		
		Product obj=new Product();
		
		obj.getProductDetail();
		obj.calculateFinalPrice();
		
		System.out.println("So you wish to continue?");
		ch=scan.next().charAt(0);
		
		scan.close();
		}while(ch=='y' || ch=='Y');
	}

}
