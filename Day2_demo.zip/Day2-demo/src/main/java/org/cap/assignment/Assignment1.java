package org.cap.assignment;
import java.util.*;
public class Assignment1 {

	public void q1(int num)
	{
		int even=2,odd=1;
	
		while(odd<num)
		{
			
			for(int j=0;j<3;j++)
			{
				if(odd>=num)
					break;
				System.out.print(odd+" ");
				odd+=2;
			}
			
			for(int j=0;j<3;j++)
				{
				
				if(even>=num)
					break;
					System.out.print(even+" ");
					even+=2;
				}
			
			
		}
	}
	
	public void q2(int num)
	{
		int sum=0,a=0;
		for(int i=0;i<num;i++)
		{
			a=num;
			sum=sum+(a%10);
			num=a/10;
			
			
		}
		
		System.out.println(sum);
	}
	
	public void q3(int num)
	{
		for(int j=1;j<num;j++)
		{
			boolean ch=false;
			if(j==1)
				System.out.println(num);
			for(int i=2;i<j;i++)
			{
				if(j%i==0 && i!=j)
				ch=true;
			}
		
			if(ch==false)
				System.out.print(j);
		}
	}
	
	public void q4(int num)
	{
		int a=0,b=0;
		double sum=0;
		
		for(int i=0;i<num;i++)
		{
			a=num;
			b=a%10;
			sum=sum+(Math.pow(b, 3));
			num=num/10;
		}
		
		System.out.print(sum);
	}
	
	public void q5(String num)
	{
		int a=num.length();
		for(int i=0;i<a+1;i++)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print(num.charAt(j));
			}
			System.out.println();
		}
	}
	
	public void q6(int num)
	{
		int a=num;
		for(int i=1;i<num;i++)
		{
			System.out.print(i);
			System.out.print("+");
			System.out.println(num-i);
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Assignment1 obj=new Assignment1();
		//obj.q1(20);
		
		//obj.q2(456);
		
		//obj.q3(20);
		
		//obj.q4(23);
		
		//obj.q5("hello");
		
		obj.q6(5);
	}

}
