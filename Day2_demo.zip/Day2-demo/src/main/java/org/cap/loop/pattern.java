package org.cap.loop;

public class pattern {
	
	public void invTriangle()
	{
		
	}

	public void numTriangle()
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*	PATTERN
		*****
		 ****
		   **
		    *
		*/
		
		/*
		for(int i=1; i<=5; i++){ 
	        for(int j=1; j <= 5; j++){
	            if(j < i){
	            	System.out.print(" ");
	            } else {
	            	System.out.print("*");
	            }
	        } 
	        System.out.println();
				
			
		}
		*/
		/*PATTERN
		1
		23
		456
		78910
		
		*/
		
		
		/*int a=1;
		
		for(int i=1;i<5;i++)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print(a);
				a++;
				
			}
		
		System.out.println();
		}*/
		
		
		/*PATTERN
					1
				1		1
			1		2		1
		1		3		3		1
		
		num=(i-j+1)/j;
	
		
		*/
		int num=0;
		
		for(int i=1;i<5;i++)
		{
			for(int j=0;j<5;j++)
			System.out.print(" ");
			
			for(int j=0;j<5;j++)
			System.out.print("1");
			
			System.out.println();
					
		}
}

}
