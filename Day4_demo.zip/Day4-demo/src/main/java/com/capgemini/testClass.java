package com.capgemini;

import static com.demo.validate.validation.*;
public class testClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//validation obj=new validation();
		
	//	obj.demo();
		show();
		
	}

}
