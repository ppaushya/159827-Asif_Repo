package org.assignment;

import java.util.Scanner;

public class Asignment4 {

	Scanner scan = new Scanner(System.in);
	
	public void Primefactor()
	{
		int number;
	      
	      System.out.println("Enter a number ::");
	      number = scan.nextInt();
	      
	      for(int i = 2; i< number; i++) {
	         while(number%i == 0) {
	            System.out.print(+i+", ");
	            number = number/i;
	         }
	      }
	      if(number >2) {
	         System.out.println(number);
	      }
	   }
	
	
	public void LetterChange()
	{
		String str;
		System.out.println("Enter a String:");
	      str = scan.nextLine();
	      
	      for(int i=0;i<str.length();i++)
	      {
	    	  int a=str.codePointAt(i);
	    	  if(a!=32)
	    	  a++;
	    	  // a=97 e=101 i=105 o=111 u=117
	    	  if( a==97 || a==101 || a==105 || a==111 || a==117)
	    	  {
	    		  a=a-32;
	    	  }
	    	  
	    	  System.out.print((char)a);
	      }
	}
	
	public void AlphabetSoup(String str)
	{
		
		int k=str.length();
	    char[]  a= new char[k];
		for(int i=0;i<k;i++)
		{
		    a[i]=str.charAt(i);
		} 
		for(int x=0;x<a.length;x++)
		{
			for(int y=x+1;y<a.length;y++)
			{
				if(a[x]>a[y])
				{
					char temp=a[x];
					a[x]=a[y];
					a[y]=temp;
				}
				
			}
			
		}
	   for(int g=0;g<a.length;g++)
	   {
		   System.out.println(a[g]);
	   }
	}
	
	public boolean anagram(String str1, String str2)
   	{
   		
   			  if (str1.length() != str2.length())
   			   return false;

   			  boolean anagram1 = true; 

   			  for (int i = 0; i < str1.length(); i++) {
   			   if (str2.indexOf(str1.charAt(i)) == -1)
   			    anagram1 = false;
   			  }
              return anagram1;
   	 }
		

	
	
	public String LetterCapitalize(String str)
		{
				int a=0;
				char[] ch=new char[str.length()];
				for(int i=0;i<str.length();i++)
				{
					ch[i]=str.charAt(i);
					
				}
			for(int i=0;i<str.length()-1;i++)
			{
				if(ch[i]==' ' && ch[i+1]==' ')
				{
					System.out.println("Two consecutive spaces are not allowed");
					System.exit(0);
				}
			}
			for(int i=0;i<str.length()-1;i++)
				{
					if(ch[0]!=' ')
					{
						if((int)(ch[0])>=97 && (int)(ch[0])<=122)
						{
							ch[0]=(char) (ch[0]-32);
						}
					}
					
					if(ch[i]==' ')
					{
						a=ch[i+1];
						if(a>=97 && a<=122)
						{
							ch[i+1]=(char) (ch[i+1]-32);
						}
					}
				
			
			}
			String str2= new String(ch);
			return str2;
				
		} 
	
	public String ReverseString(String str)
			{			char ch[]=new char[str.length()];
				for(int i=0;i<str.length();i++)
				{
					ch[i]=str.charAt(str.length()-i-1);
					
				}
				String str1=new String(ch);
				return str1;
			}
	
	public int FirstFactorial(int num)
	{
		int fact;
		if(num==0|| num==1)
			return 1;
		else 
		{
			fact=num*FirstFactorial(num-1);
		}
		return fact;
	}
	public static void main(String[] args) {
		
		Asignment4 obj=new Asignment4();
		
		//obj.Primefactor();															//Q1
		obj.AlphabetSoup("hello");													//Q2
		//System.out.println(obj.LetterCapitalize("Hello are you there"));				//Q3
		//obj.LetterChange();															//Q4
		
		String str=obj.ReverseString("Hello are you there");							//Q5
		System.out.println(str);
		
		//System.out.println(obj.anagram("hellp", "elloh"));			//Q8
		
		//System.out.println(obj.FirstFactorial(8));				//Q6
		
		
	}
	
	

}
