package org.demo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		enum_demo myDay=enum_demo.SAT;
		
		switch(myDay)
		{
		case SAT:
			System.out.println("Holiday");
			break;
		case MON:
			System.out.println("Working");
			break;
		case TUE:
			System.out.println("Still Working");
			break;
		case WED:
			System.out.println("Stillll Working");
			break;
		}
		
		
	}

}
