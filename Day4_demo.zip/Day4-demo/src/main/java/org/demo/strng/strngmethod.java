package org.demo.strng;

public class strngmethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="How are you fellow";
		
		int c=str.codePointAt(5);
		System.out.println("Char at 3 is:"+c);
		
		String s="?";
		System.out.println(str.concat(s));
		
		
		System.out.println(str.contains("ares"));
		
		
	}

}
