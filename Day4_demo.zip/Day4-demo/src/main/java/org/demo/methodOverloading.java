package org.demo;

import java.util.Scanner;

public class methodOverloading {
	
	static Scanner scan=new Scanner(System.in);
	int p,r,t;

	public methodOverloading()
	{
		p=r=t=100;
	}
	
	public double interest()
	{
		return p*r*t/100;
	}
	
	public double interest(int p)
	{
		int r=10;
		int t=5;
		
		return p*r*t/100;
	}
	
	public double interest(int p,int r)
	{
		int t=4;
		return p*r*t/100;
	}
	
	public double interest(int p,int r,int t)
	{
		return p*r*t/100;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		methodOverloading obj=new methodOverloading();
		
		System.out.println("Entetr the Principle & rate & time:");
		int p=scan.nextInt();
		int r=scan.nextInt();
		int t=scan.nextInt();
		
		double op1=obj.interest();
		double op2=obj.interest(p);
		double op3=obj.interest(p, r);
		double op4=obj.interest(p, r, t);
		
		System.out.println("The values are:\n"+op1+"\n"+op2+"\n"+op3+"\n"+op4);
		
	}

}
