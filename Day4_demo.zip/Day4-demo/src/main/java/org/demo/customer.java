package org.demo;

enum custType
{
	SILVER(101),GOLD(201),PLATINUM(301),DIAMOND(401);
	int minPoints;
	//int maxPoints;
	
	private custType(int minpoints)//int maxpoints)
	{
		this.minPoints=minPoints;
		//this.maxPoints=maxPoints;
	}
	
	public int mingetReward()
	{
		return this.minPoints;
	}
	/*public int maxgetReward()
	{
		return this.maxPoints;
	}*/
}


public class customer {
	
	int id=1032;
	String name="asd";
	custType type=custType.GOLD;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		customer obj=new customer();
		
		System.out.println(obj.id+","+obj.name+","+obj.type+","+obj.type.minPoints);
	}

	public customer(int id, String name, custType type) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
	}

}
