package org.demo;

public class str2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="tom";
		String mystr=new String("tom");
		
		//System.out.println(str==mystr);
		//System.out.println(str.equals(mystr));
		
		String mystr1=new String("tom");
		System.out.println(mystr==mystr1);
		System.out.println(mystr.equals(mystr1));
	}

}
