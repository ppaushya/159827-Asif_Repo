package Practice;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> set=new HashSet<>();
		set.add("tom");
		set.add("jack");
		set.add("sam");
		set.add("kamal");
		set.add("jerry");
		set.add("null");//bcoz its hashset
		set.add("kamal");
		set.add("jack");
		
		for(String str:set)
			System.out.print(str+" ");
		System.out.println();

	}

}
