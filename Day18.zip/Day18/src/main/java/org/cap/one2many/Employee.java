package org.cap.one2many;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
	int empId;
	String empName;
	
	@ManyToOne
	@JoinColumn(name="FK_comID")
	Company company;

	public Employee(int empId, String empName, Company company) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.company = company;
	}
	public Employee()
	{
		
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", company=" + company + "]";
	}
	

}
