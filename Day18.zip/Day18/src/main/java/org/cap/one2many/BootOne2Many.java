package org.cap.one2many;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BootOne2Many {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager em=emf.createEntityManager();
		
		EntityTransaction transaction= em.getTransaction();
		
		transaction.begin();
		
		
		
		
		Employee employee=new Employee();
		employee.setEmpId(1001);
		employee.setEmpName("RAM");
	//	employee.setCompany(company);
		
		Employee employee2=new Employee();
		employee2.setEmpId(1002);
		employee2.setEmpName("RAM");
		
		Employee employee3=new Employee();
		employee3.setEmpId(1003);
		employee3.setEmpName("RAM");
		
		
		
		
		transaction.commit();

	}

}
