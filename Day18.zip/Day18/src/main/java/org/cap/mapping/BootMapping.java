package org.cap.mapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BootMapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager em=emf.createEntityManager();
		
		EntityTransaction transaction= em.getTransaction();
		
		transaction.begin();
		
		Address address=new Address(103,"St.Peter","Chennai");
		Customer customer=new Customer(1005,"XYZ",address);
		
		em.persist(address);
		em.persist(customer);
		
		
		transaction.commit();
		
			
	}

}
