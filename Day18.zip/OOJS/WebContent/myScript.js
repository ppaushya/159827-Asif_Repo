var myFn=function(){
	console.log('Hello Good Afternoon!')
	
	
}



myFn()


var emp={
	empId:1002,
	empName:'Asif',
	Salary:50000
}

console.log(emp.empId)
console.log(emp.empName)

alert("empId" in emp)


for(key in emp)
	console.log(key+'-'+emp[key])
	
	function createEmp(empNo,name)
	{
		this.empNo=empNo;
		this.empName=name;
		
		this.printDetails=function(){
			console.log(empNo+' ' +name)
		}
	}


var employee=new createEmp(2003,"Ankita");

employee.printDetails()














function Employee(name){
	this.name=name;
	
}


Employee.prototype.getName= function(){
	return this.name
}


function Department(name,manager){
	this.name=name;
	this.manager.manager;
	
}

Department.prototype.getDepName= function(){
	return this.name;
}






dep_proto