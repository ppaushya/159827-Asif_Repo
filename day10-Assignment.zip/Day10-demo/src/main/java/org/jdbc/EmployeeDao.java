package org.jdbc;

import java.time.LocalDate;
import java.util.List;

public interface EmployeeDao {

	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	
	public List<Employee>  getAllEmployees();
	public Employee findEmployee(int empId1);
	
	public void updateEmployeeFirst(int empID, String firstName);
	public void updateEmployeeLast(int empID, String lastName);
	public void updateEmployeeSalary(int empID, Double salary);
	public void updateEmployeeDOJ(int empID, LocalDate date1);
	public Employee callProcedure(int emplyId);
	public void callBulkInsertion();
}
