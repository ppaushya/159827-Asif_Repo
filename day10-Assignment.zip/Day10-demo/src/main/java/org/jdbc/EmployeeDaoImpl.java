package org.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public void createEmployee(Employee employee) {
		String sql="insert into employee values(?,?,?,?,?)";
	
		
		/*String sql="insert into employee values("+employee.getEmpId()+"'"+employee.getFirstName()+"','"
				+ employee.getLastName()+"',"+employee.getSalary()+",'"+employee.getEmpdoj()+"')";*/
		
		try(Connection conn=getDbConnection()) {
		//	Statement statement=conn.createStatement();
			
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setInt(1, employee.getEmpId());
			statement.setString(2, employee.getFirstName());
			statement.setString(3, employee.getLastName());
			statement.setDouble(4, employee.getSalary());
			statement.setDate(5,java.sql.Date.valueOf(employee.getEmpdoj()));
			
			
			//int count=statement.executeUpdate(sql);
			int count=statement.executeUpdate();
			
			if(count>0)
				System.out.println("Insertion done!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

	@Override
	public void deleteEmployee(int employeeId) {
		
		String sql="delete from employee where empid=?";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, employeeId);
			
			int count=pst.executeUpdate();
			if(count>0)
				System.out.println("Deletion Done!");
			else
				System.out.println("Deletion Error!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}

	@Override
	public List<Employee> getAllEmployees() {
List<Employee> employees=new ArrayList<>();
		
		String sql="select * from employee";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {
				Employee employee=new Employee();
				employee.setEmpId(resultSet.getInt(1));
				employee.setFirstName(resultSet.getString(2));
				employee.setLastName(resultSet.getString(3));
				employee.setSalary(resultSet.getDouble(4));
				employee.setEmpdoj(resultSet.getDate(5).toLocalDate());
				employees.add(employee);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return employees;
	}


	@Override
	public Employee findEmployee(int empId1) {
		
List<Employee> employees=new ArrayList<>();
		
		String sql="select * from employee";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {
				Employee employee=new Employee();
				if(empId1==resultSet.getInt(1))
				{
					employee.setEmpId(resultSet.getInt(1));
					employee.setFirstName(resultSet.getString(2));
					employee.setLastName(resultSet.getString(3));
					employee.setSalary(resultSet.getDouble(4));
					employee.setEmpdoj(resultSet.getDate(5).toLocalDate());
					
					return employee;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return null;
	}


	@Override
	public void updateEmployeeFirst(int empID, String firstName) {
String sql="update employee set fname=? where id=?";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			
			statement.setString(1, firstName);
			statement.setInt(2, empID);
			
			int flag=statement.executeUpdate();
		
			
			if(flag>0)
			{
				System.out.println("Update Done!");
			}
			else
			{
				System.out.println("Update failed!! Check the Employee ID entered");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}


	@Override
	public void updateEmployeeLast(int empID, String lastName) {

		String sql="update employee set lname=? where id=?";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			
			statement.setString(1, lastName);
			statement.setInt(2, empID);
			
			int flag=statement.executeUpdate();
		
			
			if(flag>0)
			{
				System.out.println("Update Done!");
			}
			else
			{
				System.out.println("Update failed!! Check the Employee ID entered");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}


	@Override
	public void updateEmployeeSalary(int empID, Double salary) {
		String sql="update employee set salary=? where id=?";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(2, empID);
			statement.setDouble(1, salary);
			
			
			int flag=statement.executeUpdate();
		
			
			if(flag>0)
			{
				System.out.println("Update Done!");
			}
			else
			{
				System.out.println("Update failed!! Check the Employee ID entered");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}


	@Override
	public void updateEmployeeDOJ(int empID, LocalDate date1) {
		String sql="update employee set doj=? where id=?";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(2, empID);
			statement.setDate(1, java.sql.Date.valueOf(date1));
			
			
			int flag=statement.executeUpdate();
		
			
			if(flag>0)
			{
				System.out.println("Update Done!");
			}
			else
			{
				System.out.println("Update failed!! Check the Employee ID entered");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}


	@Override
	public Employee callProcedure(int employeeId) {
try(Connection conn=getDbConnection()){
			
			CallableStatement callableStatement=conn.prepareCall("{ call  findEmployee(?,?,?,?)}");
			callableStatement.setInt(1, employeeId);
			callableStatement.registerOutParameter(2,Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.DOUBLE);
			
			callableStatement.execute();
			
			String fname=callableStatement.getString(2);
			String lname=callableStatement.getString(3);
			double salary=callableStatement.getDouble(4);
			
			Employee employee=new Employee();
			employee.setFirstName(fname);
			employee.setLastName(lname);
			employee.setSalary(salary);
			employee.setEmpId(employeeId);
			
			
			return employee;
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public void callBulkInsertion() {
		String sql1="insert into employee values(11,'tom','jerry',2300,'2001-3-12')";
		String sql2="insert into employee values(21,'tom','jerry',2300,'2001-3-12')";
		String sql3="insert into employee values(33,'tom','jerry',2300,'2001-3-12')";
		String sql4="insert into employee values(44,'tom','jerry',2300,'2001-3-12')";
		String sql5="insert into employee values(55,'tom','jerry',2300,'2001-3-12')";
		
		try(Connection connection=getDbConnection() ){
		Statement statement=connection.createStatement();
		
		statement.addBatch(sql1);
		statement.addBatch(sql2);
		statement.addBatch(sql3);
		statement.addBatch(sql4);
		statement.addBatch(sql5);
		
		int[] results=statement.executeBatch();
				for(int num:results)
					System.out.println(num);
				
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
		
	}


