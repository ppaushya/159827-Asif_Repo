package org.xyz.util;

public class IdGenerator {

	private static int currentAddressNumber = 1500001;
	private static long currentCustomerNumber = 2500001;
	private static long currentAccountNumber = 3500001;
	private static long currentTransactionNumber = 4500001;
	
	public static int generateAddressNumber() {
		return ++currentAddressNumber;
	}
	
	public static long generateCustomerNumber() {
		return ++currentCustomerNumber;
	}
	
	public static long generateAccountNumber() {
		return ++currentAccountNumber;
	}
	
	public static long generateTransactionNumber() {
		return ++currentTransactionNumber;
	}
}
