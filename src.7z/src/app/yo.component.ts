import { Component } from '@angular/core';

@Component({
  selector: 'pm-base',
  templateUrl: './yo.component.html',
  styleUrls: ['./app.component.css']
})
export class Yo {
    page = 'Yo: Getting Started!';
  
}

