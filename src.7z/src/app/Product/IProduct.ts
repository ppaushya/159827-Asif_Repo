export interface IProduct{
    productId:number;
    productName:string;
    productCode:string;
    releaseDate:String;
    price:number;
    description:String;
    starRating:number;
    imageUrl:string;
}