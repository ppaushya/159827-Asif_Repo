package org.demo;

import java.util.Scanner;

public class employee {

	Scanner scan=new Scanner(System.in);
	int empId;
	String Fname,Lname;
	int age;
	double salary;
	
	public void getEmp()
	{
		

		System.out.println("Enter the Details of the Employee:");
		
		System.out.println("Emp Id:");
		empId=scan.nextInt();
		
		/*System.out.println("First Name:");
		Fname=scan.next();
		
		System.out.println("Last anme");
		Lname=scan.next();
		
		
		
		System.out.println("Age:");
		age=scan.nextInt();
		
		System.out.println("Salary:");
		salary=scan.nextDouble();*/
		
	}
	public void empPrint()
	{
		System.out.println(empId);
		
	}
	
	public int getId()
	{
		return empId;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
