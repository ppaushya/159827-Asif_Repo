package org.demo;

import java.util.Scanner;

public class Main_emp {


	employee[] emp;
	
	public void input(int num)
	{
		emp=new employee[num];
		
		for(int i=0;i<num;i++)
		{
			emp[i]=new employee();
			emp[i].getEmp();
		}
	}
	
	public void sort_emp()
	{
		employee temp=new employee();
		for(int i=0;i<emp.length;i++)
		{
			for(int j=i+1;j<emp.length;j++)
			{
				if(emp[i].getId()>emp[j].getId())
				{
					temp=emp[i];
					emp[i]=emp[j];
					emp[j]=temp;
				}
			}
		}
	}
	
	public void print()
	{
		for(int i=0;i<emp.length;i++)
		{
			
			emp[i].empPrint();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Main_emp obj=new Main_emp();
		
		System.out.println("How many emp data to be entered");
		
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		
		
		obj.input(num);
		obj.sort_emp();
		obj.print();
	}

}
