package org.demo;

public class testArray {

	public int[] getElement(int[] myArray)
	{
		for(int i=0;i<myArray.length;i++)
		myArray[i]=myArray[i]/2;
		
		return myArray;
	}
	
	public void print(int[] arr)
	{
		for(int i=0;i<myArray.length;i++)
			System.out.print(arr+",");
			
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] nums= {3,5,6,4,8};
		testArray obj=new testArray();
		obj.getElement(nums);
	}
	
	

}
