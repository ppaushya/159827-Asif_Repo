package org.demo;

public class multiDimArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[][] arr=new int[3][2];
		
		arr[0][0]=12;
		arr[0][1]=34;
		
		arr[1][0]=40;
		arr[1][1]=45;
		
		arr[2][0]=76;
		arr[2][1]=66;
		
		for(int i=0;i<3;i++)
			{for(int j=0;j<2;j++)
				System.out.print(arr[i][j]+" ");
			System.out.println();
			}
		}
	

}
