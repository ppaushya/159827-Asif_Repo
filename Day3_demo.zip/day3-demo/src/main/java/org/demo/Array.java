package org.demo;

public class Array {

	public static void main(String[] args) {
		// Short can be accomodated in the int type

		//int[] num=new int[10];					//initializing with memory allocation
		int []num= {1,2,3,4,5,8,9,6,9};						//can be initalize in one way not both 
		int size=num.length;
		/*short mynum=34;*/
		
		/*num[0]=4;
		num[6]=6;
		num[2]=3;
		
		num[5]=mynum;			//impilcit conversion
		
		num[8]=(int)3.14;			//expilcit conversion
*/		
		for(int i=0;i<size;i++)
		System.out.print(num[i]+" ");
	}

}
