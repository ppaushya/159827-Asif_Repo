package org.capg.dao;

import org.capg.model.Customer;

import com.sun.tools.javac.util.List;

public interface ICustomerDao {

	public List<Customer> getAllCustomer();
	
	public void createCustomer(Customer customer);
	
}
