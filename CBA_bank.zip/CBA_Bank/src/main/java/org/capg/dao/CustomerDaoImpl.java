package org.capg.dao;

import java.util.ArrayList;

import org.capg.model.Customer;

import com.sun.tools.javac.util.List;

public class CustomerDaoImpl implements ICustomerDao{
	
	private List<Customer> customers=dummyDb();
	
	private static List<Customer> dummyDb()
	{
		List<Customer> customers=new ArrayList();
		
	}

	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

}
