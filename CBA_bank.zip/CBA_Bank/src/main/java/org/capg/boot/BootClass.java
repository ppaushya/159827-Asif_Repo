package org.capg.boot;


import org.capg.model.Customer;
import org.capg.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		
		UserInteraction ui=new UserInteraction();
		
		ui.initialize();
		
		Customer customer=ui.getCustomer();
		System.out.println(customer);

	}

}
