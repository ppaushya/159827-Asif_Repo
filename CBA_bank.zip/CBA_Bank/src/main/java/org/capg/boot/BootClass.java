package org.capg.boot;

import org.capg.model.Customer;
import org.capg.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		
		UserInteraction ui=new UserInteraction();
		Customer customer=ui.getCustomerId();
		
		customer.setFirstName(ui.getFname());
		customer.setLastName(ui.getLname());
		customer.setEmailId(ui.getEmail());
		customer.setMobileNo(ui.getMobileNo());
		customer.setDateOfBirth(ui.getDateOfBirth());
		
		
		System.out.println(customer);

	}

}
