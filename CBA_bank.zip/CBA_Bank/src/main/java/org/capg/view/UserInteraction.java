package org.capg.view;

import java.time.LocalDate;
import java.util.Scanner;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.util.Utility;

public class UserInteraction {

	Scanner scan=new Scanner(System.in);
	
	public void initialize()
	{
		System.out.println("\t\t\t***CBA BANKING WALLET ***\n");
		
		System.out.println("1. Create Customer");
		System.out.println("2. List Customer");
	}
	
	public Customer getCustomer()
	{
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateId());
		customer.setFirstName(getFname());
		customer.setLastName(getLname());
		customer.setEmailId(getEmail());
		customer.setMobileNo(getMobileNo());
		customer.setDateOfBirth(getDateOfBirth());
		
		customer.setAddress(getAddress(customer));
		
	
		
		return customer;
	}
	
	public Address getAddress(Customer customer)
	{
		Address address=new Address();
		
		System.out.println("Enter the Address Line1:");
		address.setAddressLine1(scan.next());
		
		System.out.println("Enter the Address Line2:");
		address.setAddressLine2(scan.next());
		
		System.out.println("Enter the City:");
		address.setCity(scan.next());
		
		System.out.println("Enter the State:");
		address.setState(scan.next());
		
		System.out.println("Enter the Pincode:");
		address.setPincode(scan.next());
		
		return address;
	}
	
	public String getFname()
	{
		boolean flag=false;
		String Fname;
		do
		{
		System.out.println("Enter the First Name:");
		Fname=scan.next();
		flag=Utility.isValidName(Fname);
		
		if(!flag)
		{
			System.out.println("-->Invalid First name!\n");
		}
		
		}while(!flag);
		
		
		return Fname;
		
	}
	
	public String getLname()
	{
		boolean flag=false;
		String Lname;
		do
		{
		System.out.println("Enter the Last Name:");
		Lname=scan.next();
		flag=Utility.isValidName(Lname);
		
		if(!flag)
		{
			System.out.println("-->Invalid Last name!\n");
		}
		
		}while(!flag);
		
		
		return Lname;
		
	}
	
	public String getEmail()
	{
		boolean flag=false;
		String email;
		do
		{
		System.out.println("Enter Email Id:");
		email=scan.next();
		
		if(email.matches("^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$"))
		{
			flag=true;
		}
		if(!flag)
			System.out.println("-->Invalid EmailId!");
		}while(!flag);
		
		
		return email;
	}
	
	public String getMobileNo()
	{
		String mob;
		boolean flag=false;
		
		do
		{
		System.out.println("Enter Phone Number:"); 
		mob=scan.next();
		
		if(mob.matches("^[0-9]{10}"))
		{
			flag=true;
		}
		if(!flag)
			System.out.println("-->Invalid Number!");
		}while(!flag);
		
		
		
		return mob;
	}
	
	public LocalDate getDateOfBirth()
	{
		boolean flag=false;
		String dob;
		Integer date,month,year;
		
		do {
		System.out.println("Enter the Date(dd-mm-yyy):");
		dob=scan.next();
		
		date=Integer.parseInt(dob.substring(0, 2));
		month=Integer.parseInt(dob.substring(3,5));
		year=Integer.parseInt(dob.substring(6, 10));
		
		if(date<1 || date>31 || dob.charAt(2)!='-' || dob.charAt(5)!='-' || month<1 || month>12)
		{
			flag=false;
		}
		else 
			flag=true;
		
		if(!flag)
			System.out.println("-->Invalid dateOfBirth Format!");
		}while(!flag);
		
		return LocalDate.of(year, month, date);
	}
	
	
	public String getPincode() {
		boolean flag=false;
		String pincode;
		do {
			System.out.println("Enter pincode:");
			pincode=scan.next();
			flag=Utility.isValidPincode(pincode);
			if(!flag)
				System.out.println("Please enter Valid pincode!");
		}while(!flag);
		
		return pincode;
	}
	
	
}
