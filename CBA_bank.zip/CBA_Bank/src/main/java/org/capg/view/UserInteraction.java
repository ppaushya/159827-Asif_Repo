package org.capg.view;

import java.time.LocalDate;
import java.util.Scanner;

import org.capg.model.Customer;
import org.capg.util.Utility;

public class UserInteraction {

	Scanner scan=new Scanner(System.in);
	
	public Customer getCustomerId()
	{
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateId());
		
		return customer;
	}
	
	public String getFname()
	{
		boolean flag=false;
		String Fname;
		do
		{
		System.out.println("Enter the First Name:");
		Fname=scan.next();
		flag=Utility.isValidName(Fname);
		
		if(!flag)
		{
			System.out.println("Invalid name!");
		}
		
		}while(!flag);
		
		
		return Fname;
		
	}
	
	public String getLname()
	{
		boolean flag=false;
		String Lname;
		do
		{
		System.out.println("Enter the Last Name:");
		Lname=scan.next();
		
		if(Utility.isValidName(Lname))
		{
			flag=true;
		}
		}while(!flag);
		
		
		return Lname;
		
	}
	
	public String getEmail()
	{
		boolean flag=false;
		String email;
		do
		{
		System.out.println("Enter Email Id:");
		email=scan.next();
		
		if(email.matches("^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$"))
		{
			flag=true;
		}
		if(!flag)
			System.out.println("Invalid EmailId!");
		}while(!flag);
		
		
		return email;
	}
	
	public String getMobileNo()
	{
		String mob;
		boolean flag=false;
		
		do
		{
		System.out.println("Enter Phone Number:"); 
		mob=scan.next();
		
		if(mob.matches("^[0-9]{10}"))
		{
			flag=true;
		}
		if(!flag)
			System.out.println("Invalid Number!");
		}while(!flag);
		
		
		
		return mob;
	}
	
	public LocalDate getDateOfBirth()
	{
		boolean flag=false;
		String dob;
		Integer date,month,year;
		
		do {
		System.out.println("Enter the Date(dd-mm-yyy):");
		dob=scan.next();
		
		date=Integer.parseInt(dob.substring(0, 2));
		month=Integer.parseInt(dob.substring(3,5));
		year=Integer.parseInt(dob.substring(6, 9));
		
		if(date<1 || date>31 || dob.charAt(2)!='/' || dob.charAt(5)!='/' || month<1 || month>12)
		{
			flag=false;
		}
		else 
			flag=true;
		}while(!flag);
		
		return LocalDate.of(year, month, date);
	}
	
	
}
