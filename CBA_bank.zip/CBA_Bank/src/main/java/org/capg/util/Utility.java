package org.capg.util;

public class Utility {
	
	
	public static int generateId()
	{
		return (int)(Math.random()*10000);
	}

	public static boolean isValidName(String name)
	{
		boolean flag=false;
		if(name.matches("[a-zA-Z]{3,}"))
		{
			flag=true;
		}
		
		return flag;
	}

	public static boolean isValidPincode(String pincode) {

		return pincode.matches("//d{6}");
	}
}
