package Manage_Inventory;

import com.capstore.model.Inventory;
import com.capstore.model.Product;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	@Given("^Details of product$")
	public void details_of_product() throws Throwable {
		
		
	}

	@When("^Edit Button is clicked$")
	public void edit_Button_is_clicked() throws Throwable {
	}

	@Then("^Make all the fields editable$")
	public void make_all_the_fields_editable() throws Throwable {
	}

	@Then("^Click Save Button$")
	public void click_Save_Button() throws Throwable {
	}

	@When("^Delete Button is clicked$")
	public void delete_Button_is_clicked() throws Throwable {
	}

	@Then("^Delete Entry$")
	public void delete_Entry() throws Throwable {
	}

	
}
