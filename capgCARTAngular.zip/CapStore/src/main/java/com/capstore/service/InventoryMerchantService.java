package com.capstore.service;

public class InventoryMerchantService implements IInventoryMerchantService{

}
