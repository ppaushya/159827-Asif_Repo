package com.capstore.service;

import com.capstore.model.Customer;
import com.capstore.model.Email;

public interface IEmailService {

	void sendEmail(Email mail);

	
}
