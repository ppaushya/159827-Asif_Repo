package com.capstore.service;

public class AddressService implements IAddressService{
		
}