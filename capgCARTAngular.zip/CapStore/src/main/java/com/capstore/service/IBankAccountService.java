package com.capstore.service;

public interface IBankAccountService {

}
