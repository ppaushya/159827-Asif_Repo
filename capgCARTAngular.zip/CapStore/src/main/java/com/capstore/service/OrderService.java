package com.capstore.service;

public class OrderService implements IOrderService{

}
