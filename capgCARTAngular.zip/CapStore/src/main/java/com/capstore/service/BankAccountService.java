package com.capstore.service;

public class BankAccountService {

	public void print() {
		System.out.println("Method 1");
	}
}
