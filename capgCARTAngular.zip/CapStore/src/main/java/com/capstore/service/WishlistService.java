package com.capstore.service;

public class WishlistService implements IWishlistService{

}
