package com.capstore.dao;

public interface IReturn {

}
