package com.capstore.dao;

public interface IProductImage {

}
