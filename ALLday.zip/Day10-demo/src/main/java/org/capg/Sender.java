package org.capg;

public class Sender<T,R> {
	
	T messages;
	R message2;

	public R getMessage2() {
		return message2;
	}

	public void setMessage2(R message2) {
		this.message2 = message2;
	}

	public T getMessages() {
		return messages;
	}

	public void setMessages(T messages) {
		this.messages = messages;
	}
	
	

}
