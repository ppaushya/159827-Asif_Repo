package org.capg1;

public interface employeeDao {
	
	public void createEmployee(employee emp);

}
