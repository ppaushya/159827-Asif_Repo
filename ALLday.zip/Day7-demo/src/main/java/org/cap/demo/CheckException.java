package org.cap.demo;

public class CheckException {

	public static void main(String[] args) {
		
		int num1=100;
		//int num2=45;
		int num2=0;
		int result=0;
		try {
		
			result=num1/num2;
		}
		/*catch(ArithmeticException e)
		{
			//System.out.println(e.getMessage());
			e.printStackTrace();
		}*/
		
		catch(NumberFormatException  | ArithmeticException e)
		{
			e.printStackTrace();
		}
		
		
		
		
		System.out.println("Result:"+result);
	
	

}
}
