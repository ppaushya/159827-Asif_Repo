package org.cap.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class demo2 {



	public static void main(String[] args) {
		// TODO Auto-generated method stub


		File file=new File("c:\\sample\\data.txt");
		try 
		{
		FileInputStream inputStream=new FileInputStream(file);
		}catch(FileNotFoundException e)
		
		{
			e.printStackTrace();
		}
	}

	
	

	
}
