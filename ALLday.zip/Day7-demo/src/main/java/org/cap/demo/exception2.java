package org.cap.demo;

public class exception2 {

	public static void main(String[] args) {
		Integer num1=100;
		Integer num2=null;
		Integer ans=null;
		
		try
		{
			ans=num1+num2;
			System.out.println("Answer:"+ans);
		}catch(NumberException e)
		{
			
		}

	}

}
