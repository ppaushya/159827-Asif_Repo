package org.cap.demo;

public class asd {

	public static void main(String args) {
		// TODO Auto-generated method stub

		for(int i=0;i<3;i++)
			System.out.println(args + " ");
	}

}
