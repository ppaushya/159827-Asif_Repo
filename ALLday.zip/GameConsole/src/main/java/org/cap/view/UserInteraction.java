package org.cap.view;

import java.util.Scanner;

import org.cap.model.Registration;
import org.cap.service.IRegistrationService;
import org.cap.service.RegistrationServiceImpl;

public class UserInteraction {
	
	Scanner scan=new Scanner(System.in);
	IRegistrationService registrationService=new RegistrationServiceImpl();

	public void createCustomer() {
		Registration registration=new Registration();

		System.out.println("\t\t\t***Game Portal***");
		
		
		registration.setCustomerName(getName());
		registration.setAge(getAge());
		registration.setMobileNo(getMobile());
		registration.setRegistrationFee(getFee());
		
		registration.setActualPaid(Utility.getActualPaid(registration.getRegistrationFee()));
		
		registrationService.createCustomer(registration);
	}

	private double getFee() {
boolean flag=false;
		
		do {
			System.out.println("Enter Registration Fee:");
			double Fee=scan.nextDouble();
			
			
			flag=Fee>0;				//fee should be postive no.
			if(!flag)
				System.out.println("Invalid Fee!!");
			else
				return Fee;
			
		}while(!flag);
		
		return 0;
	}

	private String getMobile() {
		boolean flag=false;
		
		do {
			System.out.println("Enter your Mobile No:");
			String mobile=scan.next();
			
			
			flag=mobile.matches("[0-9]{10}");
			if(!flag)
				System.out.println("Invalid Mobile No.!!");
			else
				return mobile;
			
		}while(!flag);
		return null;
	}

	private int getAge() {
		boolean flag=false;
		
		do {
			System.out.println("Enter your Age:");
			int age=scan.nextInt();
			
			
			flag=age>18;
			if(!flag)
				System.out.println("You should be aove 18 yrs to Register!!");
			else
				return age;
			
		}while(!flag);
			return 0;
	}

	private String getName() {
		boolean flag=false;
		
	do {
		System.out.println("Enter your name:");
		String name=scan.next();
		
		
		flag=name.matches("[a-zA-Z]");
		if(!flag)
			System.out.println("Invalid Name!!");
		else
			return name;
		
	}while(!flag);
		return null;
	}
	

}
