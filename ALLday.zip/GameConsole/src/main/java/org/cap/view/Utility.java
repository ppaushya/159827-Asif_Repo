package org.cap.view;

public class Utility {

	public static double getActualPaid(double registrationFee) {

		if(registrationFee<18)
			return (registrationFee);
		else if(registrationFee>18 && registrationFee<25)
			return (registrationFee+ (registrationFee*0.1));
		else if(registrationFee<25 && registrationFee<50)
			return (registrationFee+ (registrationFee*0.2));
		else if(registrationFee >50)
			return (registrationFee+(registrationFee*0.3));
			
		
		return 0;
	}
	

}
