package org.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.cap.model.Registration;

public class RegistrationDaoImpl implements IRegistrationDao {

	@Override
	public void createCustomer(Registration registration) {
		
		String sql="insert into employee values(?,?,?,?,?)";
		
		/*String sql="insert into employee values("+employee.getEmpId()+"'"+employee.getFirstName()+"','"
				+ employee.getLastName()+"',"+employee.getSalary()+",'"+employee.getEmpdoj()+"')";*/
		
		try(Connection conn=getDbConnection()) {
		//	Statement statement=conn.createStatement();
			
			PreparedStatement statement=conn.prepareStatement(sql);
			
			statement.setString(2, registration.getCustomerName());
			statement.setInt(3,registration.getAge());
			statement.setString(4, registration.getMobileNo());
			statement.setDouble(5, registration.getActualPaid());
			
			
			
			//int count=statement.executeUpdate(sql);
			int count=statement.executeUpdate();
			
			if(count>0)
				System.out.println("Insertion done!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
