package org.cap.service;

import org.cap.model.Registration;

public interface IRegistrationService {

	void createCustomer(Registration registration);

}
