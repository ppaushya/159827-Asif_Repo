package org.capg.util;

public enum AccountType {
	SAVINGS,CURRENT,RD,FD;
}
