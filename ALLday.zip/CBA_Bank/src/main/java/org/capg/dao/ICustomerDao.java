package org.capg.dao;

import org.capg.model.Account;
import org.capg.model.Customer;
import java.util.List;
import java.util.Set;


public interface ICustomerDao {

	public List<Customer> getAllCustomers();
	
	public void createCustomer(Customer customer);

	public void createAccount(Account account, Customer customer);

	

	
}
