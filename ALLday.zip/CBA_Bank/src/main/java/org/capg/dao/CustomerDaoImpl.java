package org.capg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Address;
import org.capg.model.Customer;


public class CustomerDaoImpl implements ICustomerDao{
	
	private static List<Customer> customers=dummyDb();
	
	
	private static List<Customer> dummyDb()
	{
		List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("asdafa","adfdge","Chennai","TN","654897");
		customers.add(new Customer(1056,"John","Patrik","john@gmail.com","9876543218",LocalDate.of(1991, 01, 03),address));
		
		Address address1=new Address("St josep","2nd Street","Bangalore","Karnataka","325478");
		customers.add(new Customer(2054,"Kiran","Kumar","kiran@gmail.com","7563248963",LocalDate.of(1980, 05, 12),address1));
		
		Address address2=new Address("St. Gosip","Geral","Surat","Gujrat","856201");
		customers.add(new Customer(5698,"Madhav","Nath","madhav@yahoo.com","7976543218",LocalDate.of(2011, 11, 05),address2));
		
		Address address3=new Address("Thsak","lopsd","kild","poi","254897");
		customers.add(new Customer(1056,"Deepak","jain","jain@gmail.com","7896543218",LocalDate.of(2018, 01, 03),address3));
		
		
		return customers;
	}

	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	public void createCustomer(Customer customer) {
		
		customers.add(customer);
	}
	
	public void createAccount(Account account,Customer customer)
	{
		Set<Account> accounts=customer.getAccount();
		accounts.add(account);
	}
	
	
	


}
