package org.capg.boot;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.view.UserInteraction;
import org.capg.view.UserTransaction;

public class BootClass {

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		
		UserInteraction userInteraction=new UserInteraction();
		ICustomerService customerService=new CustomerServiceImpl();
		Account account=new Account();
		UserTransaction userTransaction=new UserTransaction();
		Transaction transaction=new Transaction();
		
		do {	
		int choice=userInteraction.initialize();
		
	
		switch (choice)
		{
		case 1:
			
			Customer customer=userInteraction.getCustomer();
			customerService.createCustomer(customer);
			break;
			
		case 2:
			List<Customer> customers=customerService.getAllCustomers();
			userInteraction.printAllCustomers(customers);
			
			break;
			
		case 3:
			customers=customerService.getAllCustomers();
			userInteraction.printAllCustomers(customers);
			
			userInteraction.getAccountDetails();
			
			
			break;
			
		case 4:
			customers=customerService.getAllCustomers();
			userInteraction.printAllCustomers(customers);
			
			userTransaction.getTransaction();
			
			
			break;
			
		case 5:
			break;
		
		case 6:
			System.out.println("Are sure you want to exit!!! [y/n]");
			String ch=scan.nextLine();
			System.out.println(ch.charAt(0));
			if(ch.charAt(0)=='Y' || ch.charAt(0)=='y')
			System.exit(0);
			else 
				break;
			
		default:
			System.out.println("Invalid choice!!");
			break;
		}
			
		}while(true);
		
		
		

	}

}
