package org.capg.view;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.CustomerServiceImpl;
import org.capg.util.Utility;

public class UserTransaction {
	
	Scanner scan=new Scanner(System.in);
	CustomerServiceImpl customerService=new CustomerServiceImpl();
	Set<Account> accounts=new HashSet();
	
	public void getTransaction()
	{
		Transaction transaction=new Transaction();
		
		List<Customer> customers=customerService.getAllCustomers();
		
		System.out.println("Enter the customer number to add the account:");
		int customerId=scan.nextInt();
		
		
		if(Utility.isValidCustomerId(customers,customerId))
		{
			System.out.println("Valid Customer..");
			Customer customer=Utility.findCustomer(customerId,customers);
			
			if(customer!=null)
			{
				accounts=customer.getAccount();
				Utility.printAccounts(accounts);
				
				System.out.println("Enter the account number for Transaction:");
				long accountNo=scan.nextLong();
				
				if(Utility.isValidAccountNo(accounts,accountNo))
				{
					System.out.println("Valid Account..");
					Account account=Utility.findAccount(accountNo,accounts);
					if(account!=null)
					{
						transaction.setTransactionId((long)Utility.generateId());
						transaction.setTransactionType(getTransactionType());
						transaction.setAmount(getAmount());
						transaction.setToAccount(account);
						transaction.setFromAccount(getFromAccount());
					}
				}
		
			}

		}
		
		customerService.performTransaction();
	}

	private Account getFromAccount() {
		
		System.out.println("Enter the Account no from which transaction is to be done:");
		long accountNo=scan.nextInt();
		
		if(Utility.isValidAccountNo(accounts,accountNo))
		{
			System.out.println("Valid Account..");
			Account account=Utility.findAccount(accountNo,accounts);
			if(account!=null)
			{

				return account;
			}
			
				
		}
		return null;
	}

	private double getAmount() {
		System.out.println("Enter the Amount:");
		int ch=scan.nextInt();
		return 0;
	}

	private String getTransactionType() {


		boolean flag=false;
	do {
		System.out.println("Want you want to do?");
		System.out.println("1.Deposit\n2.Withdrawl");
		
		int ch=scan.nextInt();
		if(ch==1||ch==2)
			flag=true;
		else 
			flag=false;
		
		switch (ch)
		{
		case 1:
			return "credit";
			
		case 2:
			return "debit";
		
		}
	
		if(!flag)
			System.out.println("Invalid option!!");
	}while(!flag);
		return null;
	}
}