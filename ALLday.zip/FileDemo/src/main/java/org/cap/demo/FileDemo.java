package org.cap.demo;

import java.io.File;

public class FileDemo {

	public static void main(String[] args) {
		
		File file=new File("D:\\Users\\muasif\\Desktop\\FileDemo\\fileDemo.txt");
		if(file.isFile())
		{
		if(file.exists())
		{
			System.out.println("readable:"+ file.canRead());
			System.out.println("readable:"+ file.canWrite());
			System.out.println("readable:"+ file.canExecute());
			System.out.println("readable:"+ file.getAbsolutePath());
			
		}
		else
			System.out.println("Sorry No file!!");
		}
		else if(file.isDirectory())
		{
			String[] names=file.list();
			
			for(String name:names)
				System.out.println(name);
		}
		else
			System.out.println("SorrY no Directory!");
		
		System.out.println(file.getFreeSpace());
		System.out.println(file.getTotalSpace());
		System.out.println(file.getUsableSpace());

	}

}
