package org.cap.employee;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class EmployeeFile {

	public static void main(String[] args) {
		
		int id=10;
		boolean status=true;
		double salary=567.0;
		
		String name="Ankita";
		int size=name.length();
		
		
		
		File file=new File("D:\\Users\\muasif\\Desktop\\FileDemo\\employee.txt");
		
		try(FileOutputStream out=new FileOutputStream(file))
		{
			DataOutputStream outputStream=new DataOutputStream(out);
			
			for(int i=0;i<5;i++)
			{
			outputStream.writeInt(id);
			outputStream.writeBoolean(status);
			outputStream.writeDouble(salary);
			outputStream.writeInt(size);
			outputStream.write(name.getBytes());
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try(FileInputStream in=new FileInputStream(file))
		{
			DataInputStream inputStream=new DataInputStream(in);
			
			for(int i=0;i<5;i++)
			{
				System.out.println(inputStream.readInt());
				System.out.println(inputStream.readBoolean());
				System.out.println(inputStream.readDouble());
				int a=inputStream.readInt();
				//System.out.println(inputStream.readNBytes(b, off, len));
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
