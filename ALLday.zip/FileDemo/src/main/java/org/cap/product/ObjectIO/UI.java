package org.cap.product.ObjectIO;

import java.time.LocalDate;
import java.util.Scanner;

public class UI {

	Scanner scan=new Scanner(System.in);
	
	public Product getProduct() {
		
		Product product=new Product();
		
		System.out.println("Enter the product Id:");
		product.setProductInt(scan.nextInt());
		
		System.out.println("Enter the product Name:");
		product.setProductName(scan.next());
		
		System.out.println("Enter the Quantity:");
		product.setQuantity(scan.nextInt());
		
		System.out.println("Enter the Price:");
		product.setPrice(scan.nextDouble());
		
		System.out.println("Enter the date of Expiry:");
		product.setExpiryDate(LocalDate.now());
		
		return product;
	}
	
	

}
