package com.demo.validate;

public class validation {
	
		int count=100;
		static int num=302;
		
		public void demo()
		{
			System.out.println("Hello ! this is instance memeber");
		}

		public static void show()
		{
			System.out.println("Static Members");
			//System.out.println("Count:"+count);
			System.out.println("number:"+num);
			
			
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
