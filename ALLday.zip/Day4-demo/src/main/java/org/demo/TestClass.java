package org.demo;

import java.util.Arrays;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr= {10,56,69,58,25};
		Arrays.sort(arr);
		
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");
		
		System.out.println();
		
		String[] names= {"Hello ","How ","Are ","You " ," ?"};
		Arrays.sort(names);
		
		//for(int i=0;i<names.length;i++)
		//System.out.print(names[i]+" ");
		
		int[] arr2=Arrays.copyOf(arr,3);
		//print copied array
		for(int i=0;i<arr2.length;i++)
			System.out.print(arr2[i]+" ");
		
		System.out.println();
		
		int[] arr3=Arrays.copyOfRange(arr,3,5);
		//print copied array
		for(int i=0;i<arr3.length;i++)
			System.out.print(arr3[i]+" ");
		
		//binary search
		System.out.println();
		int result=Arrays.binarySearch(arr, 56);
		System.out.print(result);
	}

}
