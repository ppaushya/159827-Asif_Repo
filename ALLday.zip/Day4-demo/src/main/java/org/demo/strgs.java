package org.demo;

public class strgs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="tom";
		String mystr=new String("Jerry");
		String myname="tom";
		
		System.out.println(str);
		System.out.println(mystr);
		System.out.println(str.hashCode());
		System.out.println(mystr.hashCode());
		System.out.println(myname.hashCode());
		
		
	}

}
