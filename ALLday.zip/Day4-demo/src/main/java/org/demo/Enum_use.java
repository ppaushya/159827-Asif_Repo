package org.demo;

import java.util.Scanner;

public class Enum_use {
	
	Scanner scan=new Scanner(System.in);
	int empId;
	String Name;
	int age;
	enum_demo weekOf;
	
	public void getData()
	{
		System.out.println("Id:");
		empId=scan.nextInt();
		
		System.out.println("Name:");
		Name=scan.next();
		
		System.out.println("age:");
		age=scan.nextInt();
		
		System.out.println("Select DAY Code:");
		System.out.println("1:Sunday");
		System.out.println("2:Monday");
		System.out.println("3:Tuesday");
		System.out.println("4:Wednesday");
		System.out.println("5:Thursday");
		System.out.println("6:Friday");
		System.out.println("7:Satday");
		
		int ch=scan.nextInt();
		switch(ch)
		{
		case 1:
			weekOf=enum_demo.SUN;
			break;
		case 2:
			weekOf=enum_demo.MON;
			break;
		case 3:
			weekOf=enum_demo.TUE;
			break;
		case 4:
			weekOf=enum_demo.WED;
			break;
		case 5:
			weekOf=enum_demo.THU;
			break;
		case 6:
			weekOf=enum_demo.FRI;
			break;
		case 7:
			weekOf=enum_demo.SAT;
			break;
		default: 
			System.out.println("Invalid");
			break;
		}
		
	}
	
	public void print()
	{
		System.out.println(empId);
		System.out.println(Name);
		System.out.println(age);
		System.out.println(weekOf);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Enum_use obj=new Enum_use();
		obj.getData();
		obj.print();
	}

}
