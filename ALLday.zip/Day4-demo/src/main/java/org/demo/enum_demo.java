package org.demo;

public enum enum_demo {

	SUN,MON,TUE,WED,THU,FRI,SAT;
	
	
}
