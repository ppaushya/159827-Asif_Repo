package org.assignment;

import java.util.Scanner;

public class Assignment {
	
	public void Primefactor()
	{
		int number;
	      Scanner sc = new Scanner(System.in);
	      System.out.println("Enter a number :");
	      number = sc.nextInt();
	      
	      for(int i = 2; i< number; i++) {
	         while(number%i == 0) {
	            System.out.print(+i+", ");
	            number = number/i;
	         }
	      }
	      if(number >2) {
	         System.out.println(number);
	      }
	   }
	
	public void AlphabetSoup(String str)
	{
		char b=0;
		int k=str.length();
		char[] ch= new char[k];
		for(int i=0;i<k;i++)
		{
		    b=ch[i];
		}
	   for(int a=0;a<k;a++)
		{
			for(int x=a+1;x<k;x++)
			{
				if(b>ch[x])
				{
					char temp=ch[x];
					ch[x]=b;
					b=temp;
				}
				
			}
			System.out.print(ch[a]);	
			
		}
		
	}
	
	public void findfactorial(int num)
	{
		int fact=1;
		for(int i=num;i>=1;i--)
		{
			fact=fact*i;
		}
		System.out.println("Factorial is:"+fact);
	}
	public boolean anagram(String str1, String str2)
	{
		 
			  // if length itself not equal, return false.
			  if (str1.length() != str2.length())
			   return false;
			  // else do the brainstorming!
			  boolean anagram1 = true;

			  for (int i = 0; i < str1.length(); i++) {
			   if (str2.indexOf(str1.charAt(i)) == -1)
			    anagram1 = false;
			  }
           return anagram1;
	 }
	
	public void ReverseOrder(char[] str)
	{
		 int n = str.length;
	        int start = 0;
	        for(int i = 0; i < n; i++) 
	           {
	            if(str[i]==  ' ' && i > 0) 
	              {
	                reverse(str, start, i-1);
	                start = i+1;
	               }
	            else if(i == n-1) 
	            {
	                reverse(str, start, i);
	            }
	        }
	        reverse(str, 0, n-1);
	    }
	 private static void reverse(char[] str, int start, int end) {
	        while(start < end) {
	            swap(str, start, end);
	            start++;
	            end--;
	        }
	    }
	 
	    private static void swap(char[] str, int start, int end) {
	        char tmp = str[start];
	        str[start] = str[end];
	        str[end] = tmp;
	    }
	

		public void Longestword(String input)
		{
			
		}
	

	public static void main(String[] args) {
	      Assignment obj=new Assignment();
	      obj.Primefactor();
	      //obj.AlphabetSoup("vaibhav");
	     // obj.findfactorial(5);
	    //  boolean a=obj.anagram("save", "vase");
	      //  System.out.print(a);
	     // obj.ReverseOrder("Hello World and Coders");
	     // char[] str = "Hello World And Coders".toCharArray();
	     // obj.ReverseOrder(str);
	      //System.out.print(str);


	}

}
