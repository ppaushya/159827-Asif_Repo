package org.demo;

public class bootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Encapsulatn obj=new Encapsulatn();
		
		obj.setStuId(1003);
	
		System.out.println(obj.getStuId());
	}

}
