package org.demo;

public class parent extends grandParent{

	public void show()
	{
		System.out.println("parent->"+num);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
}
