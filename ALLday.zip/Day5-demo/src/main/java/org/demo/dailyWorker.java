package org.demo;

public class dailyWorker extends worker {
	

	public dailyWorker(String name, int salRate) {
		super(name, salRate);
	}

	

	@Override
	public double ComPay(int hrs) {
		return hrs/24*salRate;
	}

	public static void main(String[] args) {

		dailyWorker obj=new dailyWorker("Asif",34);
		System.out.println(obj.ComPay(200));
	}
}
