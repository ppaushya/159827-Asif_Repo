package org.demo;

public abstract class worker {

	String name;
	int salRate;
	public abstract double ComPay(int hrs);

	public worker(String name, int salRate) {
		
		this.name = name;
		this.salRate = salRate;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
