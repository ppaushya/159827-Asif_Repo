package org.demo;

public class Encapsulatn {

	private int stuId;
	private String name;
	private double regFee;
	
	
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getRegFee() {
		return regFee;
	}
	public void setRegFee(double regFee) {
		this.regFee = regFee;
	}
	public Encapsulatn() {
		
		this.stuId = 102;
		this.name = "name";
		this.regFee = 256.0;
	}
	
	
	
	

}
