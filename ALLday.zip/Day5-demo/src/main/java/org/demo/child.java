package org.demo;

public class child extends parent{

	public void show()
	{
		System.out.println("parent->"+num);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
