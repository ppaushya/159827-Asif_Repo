package org.demo;

public class main_abstrt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		call_abstrct obj=new call_abstrct();
		
		System.out.println("Area:"+obj.calcualteArea());
		
		
	} 

}
