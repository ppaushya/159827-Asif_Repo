package org.demo;

import java.util.Scanner;

public class inhrtnceChild extends inhrtnce {

	boolean permanent;
	public inhrtnceChild()
	{
	}
	 
	public inhrtnceChild(boolean permanent,int personId,String name) {
	
		super(personId,name);
		this.permanent = permanent;
		
		
	}

	public inhrtnceChild(boolean permanent) {
		
		this.permanent = permanent;
	}
	public boolean gett()
	{
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Permanent(true/false):");
		permanent=scan.nextBoolean();
		return permanent;
	}
	public void show()
	{
		System.out.println("Child-> Show()");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		inhrtnceChild obj=new inhrtnceChild(true,1002,"asif");
		
		//obj.get();
		//System.out.println(obj.gett());

		//System.out.println(obj.personId);
		//System.out.println(obj.name);
		//System.out.println(obj.permanent);
		
		//obj.print();

		/*inhrtnce per=new inhrtnceChild();
		per.get();*/
		
		obj.show();
	}

}
