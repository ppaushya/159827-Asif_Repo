package org.demo;

public interface Shape {
	
	public final static int num=100;
	
	public abstract void draw();
	public abstract void info();
	
	public static void show()
	{
		details();
		System.out.println("shape interface show method");
		
	}

	default void shapePoints()
	{
		details();
		System.out.println("shape interface points method");
		
	}
	
	private static void details()
	{
		details();
		System.out.println("shape interface details method");
		
	}
	
}
