package org.demo;

public class family_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		family_main obj=new family_main();
		
	}

}
