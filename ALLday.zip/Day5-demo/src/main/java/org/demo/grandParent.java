package org.demo;

public class grandParent {

	int num=100;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
