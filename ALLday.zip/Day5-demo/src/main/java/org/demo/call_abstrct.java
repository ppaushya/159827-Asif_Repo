package org.demo;

public class call_abstrct extends abstrClass {

	public float calcualteArea()
	{
		return 3.14f*3*3;
	}
	
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("???");
	}

}
