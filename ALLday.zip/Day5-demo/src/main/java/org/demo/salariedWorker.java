package org.demo;

public class salariedWorker extends worker{

	public salariedWorker(String name, int salRate) {
		super(name, salRate);
	}

	

	@Override
	public double ComPay(int hrs) {
		return 40*salRate;
	}
	
	
	public static void main(String[] args) {
		

		salariedWorker obj=new salariedWorker("Asif",34);
		System.out.println(obj.ComPay(20));
	}

}
