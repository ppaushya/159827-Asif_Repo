package org.demo;

import java.util.Scanner;

public class inhrtnce {

	private int personId;
	private String name;
	

	public inhrtnce()
	{
		
	}
	public inhrtnce(int personId, String name) {
		
		this.personId = personId;
		this.name = name;
	}

	public void get()
	{
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter Id:");
		personId=scan.nextInt();
		
		System.out.println("Enter name:");
		name=scan.next();
		
		
	}
	
	public void show()
	{
		System.out.println("Parent-> Show()");
	}
	
	public void print()
	{
		System.out.println("Id:"+personId);
		System.out.println("name:"+name);

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
