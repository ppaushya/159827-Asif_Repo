package org.demo;

public abstract class abstrClass {
	
	int h;
	int w;
	public void info()
	{
		
		System.out.println("Information");
	}
	
	public abstract void draw();
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
