package assignment.balance;
import assignment.balance.account.*;

/*
 *Write a program to make a package Balance in which has Account class
with Display_Balance method in it. Import Balance package in another program to
access Display_Balance method of Account class.
 */

public class MainClass {
	public static void main(String[] args)
    {
    account obj=new account();
    obj.getBalance(7000);
    obj.Display_Balance();
    }
}
