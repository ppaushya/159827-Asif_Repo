package assignments;

/*
Create an Interface having two methods division and modules. Create a
class, which overrides these methods.
 */

public interface Q3_course {

	public void division(int a);
    public void modules(int b);
}
