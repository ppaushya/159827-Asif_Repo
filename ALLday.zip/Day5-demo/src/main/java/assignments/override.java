package assignments;

public @interface override {

}
