import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

public class demoAdjsuter {

	public static void main(String[] args) {
		
		LocalDate now=LocalDate.now();
		
		LocalDate nextSun=now.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
		System.out.println(nextSun);
	}
}
