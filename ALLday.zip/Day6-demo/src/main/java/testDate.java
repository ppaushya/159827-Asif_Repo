import java.util.Date;

public class testDate {

	public static void main(String[] args) {

		Date obj=new Date();
		System.out.println(obj);
		//Date obj1=new Date(1991,01,23);
		Date obj1=new Date(2012-1900,01,23);

		System.out.println(obj1);
		System.out.println(obj1.getTime());
		//System.out.println(obj1.g);
		
		Date obj2=new Date(667247400000L);

		System.out.println(obj2);
		
		System.out.println(obj1.after(obj2));

		System.out.println(obj.getYear());
		
		System.out.println(obj1.getDay());

		

		


	}

}
