package com.project.accounts;

import java.time.LocalDate;


public class Account {
	private long accountNo;
	private accountType account_Type;
	private LocalDate openDate;
	private double openBal;
	
	public Account()
	{
		
	}
	public Account(long accNo, accountType acc_Type, LocalDate openDate, double openBal) {
		super();
		this.accountNo = accNo;
		this.account_Type = acc_Type;
		this.openDate = openDate;
		this.openBal = openBal;
	}
	
	public long getAccNo() {
		return accountNo;
	}

	public void setAccNo(long accNo) {
		this.accountNo = accNo;
	}

	public accountType getAcc_Type() {
		return account_Type;
	}

	
	public void setAcc_Type(accountType acc_Type) {
		this.account_Type = acc_Type;
	}

	public LocalDate getOpenDate() {
		return openDate;
	}

	public void setOpenDate(LocalDate openDate) {
		this.openDate = openDate;
	}

	public double getOpenBal() {
		return openBal;
	}

	

	public void setOpenBal(double openBal) {
		this.openBal = openBal;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", account_Type=" + account_Type + ", openDate=" + openDate
				+ ", openBal=" + openBal + "]";
	}


	
}
