package com.project.accounts;

import java.time.LocalDate;
import java.util.Scanner;

public class mainProjects {
	
		static Customer cust[]=new Customer[4];
		static Transaction[] transaction=new Transaction[100];
		
		static Scanner scanner=new Scanner(System.in);
		
		
		public static Customer[]  start()
		{
			//Account account1=new Account(transactionFn.generateAccountNo(),accountType.SAVING,LocalDate.now(), 45000);
			Address address1=new Address("South Avennue", "Cross St", "Hyderabad", "AP");
			cust[0]=new Customer(1001,"Abc",address1,new Account[5],"45668","abc@cp");
			
			//Account account2=new Account(transactionFn.generateAccountNo(),accountType.SAVING,LocalDate.now(), 55000);
			Address address2=new Address("South Avennue", "Cross St", "Hyderabad", "AP");
			cust[1]=new Customer(1002,"Abc",address2,new Account[5],"45668","abc@cp");
			
			//Account account3=new Account(transactionFn.generateAccountNo(),accountType.SAVING,LocalDate.now(), 65000);
			Address address3=new Address("South Avennue", "Cross St", "Hyderabad", "AP");
			cust[2]=new Customer(1003,"Abc",address3,new Account[5],"45668","abc@cp");
			
			//Account account4=new Account(transactionFn.generateAccountNo(),accountType.SAVING,LocalDate.now(), 95000);
			Address address4=new Address("South Avennue", "Cross St", "Hyderabad", "AP");
			cust[3]=new Customer(1004,"Abc",address4,new Account[5],"45668","abc@cp");
		
			return cust;
		}
		
		public static void printCustomer() {
			System.out.println("Available Customers:");
			Customer[] customers=start();
			for(Customer customer:customers) {
				System.out.println(customer.getCustId()+"\t"+customer.getName() +"\t"
						+customer.getEmailId()+"\t"+ customer.getMobNo());
			}
			
		}

		public static void printAccountType() {
			accountType[] types=accountType.values();
			int count=0;
			for(accountType type:types)
				System.out.println(++count + "." + type);
		}


		private static Customer findCustomer(int customerId) {
			for(Customer customer:start()) {
				if(customer.getCustId()==customerId)
					return customer;
			}
			return null;
		}
		
		public static accountType assignAccountType(int value) {
			switch(value) {
			case 1:
				return accountType.SAVING;
			case 2:
				return accountType.CURRENT;
			case 3:
				return accountType.RD;
			case 4:
				return accountType.FD;
			default:
				System.out.println("Invalid Account Type");
				System.exit(0);
			}
			
			return null;
		}


		public static void printTransactionSummary(Transaction[] transactions) {
			System.out.println("\nTransaction Summary\n--------------------\n");
			
			for(Transaction transaction:transactions) {
				if(transaction!=null) {
				System.out.println(transaction.getTransactionDate() +"\t"
						+ transaction.getTransactionId()+"\t"
						+ transaction.getAccount().getAccNo()+"\t"
						+transaction.getTransactionType()+"\t"
						+transaction.getAmount()
						);
				}
			}
		}
		public static void printCurrentBAl(Transaction[] transactions,Customer customer) 
		{
			double currentBal=0;
			
			transactionFn tx=new transactionFn();
			System.out.println("Enter the account no:");
			long accountNo=scanner.nextInt();
			if(tx.isValidAccount(accountNo, customer))
			{
			
			System.out.println("\nCurrent Balance\n--------------------\n");
			
			for(Transaction transaction:transactions) {
				if(transaction!=null) {
				if(transaction.getAccount().getAccNo()==accountNo)
				{
					currentBal+=transaction.getAccount().getOpenBal();
				}
				}
			}
			
			for(Transaction transaction:transactions) {
				if(transaction!=null) {
					
				if(transaction.getTransactionType()=="credit" && transaction.getAccount().getAccNo()==accountNo)
				{
					currentBal+=transaction.getAmount();
				}
				else if(transaction.getTransactionType()=="debit" && transaction.getAccount().getAccNo()==accountNo)
					{
						currentBal-=transaction.getAmount();
					}
				}
			}
			
			
			}
			else
				System.out.println("Invalid Account No.! ");
			System.out.println(currentBal);
		}
		
	public static void main(String[] args) {
		char myChoice;
	
		System.out.println("\t\t\t\t----XYZ ONLINE BANKING----");
		
		mainProjects obj=new mainProjects();
		

		obj.printCustomer();
		
		System.out.println("Choose customer Id:");
		int customerId = scanner.nextInt();
		int choice;
		
		Customer customer=findCustomer(customerId);
		do {
		
		if(customer!=null)
		{
			System.out.println("1.Create new Account");
			System.out.println("2.Perform Transaction");
			System.out.println("2.Transaction Summary");
			System.out.println("4.Current Balance");
			System.out.println("Enter your Choice[1,2,3,4]?");
			choice=scanner.nextInt();
			if(choice==1)
			{
				Account account=new Account();
				System.out.println("Enter Account details");
				account.setAccNo(transactionFn.generateAccountNo());
				
				System.out.println("Choose Account Type[1,2,3,4]:");
				printAccountType();
				int accountTypeNo=scanner.nextInt();
				account.setAcc_Type(assignAccountType(accountTypeNo));
			
			System.out.println("Enter account OpeningDate:");
			System.out.println("Enter year:");
			int year=scanner.nextInt();
			System.out.println("Enter Month:");
			int month=scanner.nextInt();
			System.out.println("Enter dayOfMonth:");
			int dayOfMonth=scanner.nextInt();
			
				LocalDate date=LocalDate.of(year, month, dayOfMonth);
				account.setOpenDate(date);
				
			System.out.println("Enter Opening Balance:");
			account.setOpenBal(scanner.nextDouble());
			
			Account[] account2=customer.getAccount();
			//System.out.println(account);
			for(int i=0;i<account2.length;i++)
			{
				if(account2[i]==null) {
					account2[i]=account;
					break;
					}
			}System.out.println(customer);
		

			}else if(choice==2) 
				{
				int index=0;
				transactionFn tx=new transactionFn();
				Transaction transactions;
		
				System.out.println("Choose Any one of the account number:");
				if(customer.getAccount()[0]!=null)
					tx.printAccounts(customer);
				else
					System.out.println("Sorry! No account details present for this Customer.");
				long accountNo=scanner.nextLong();
				
				if(tx.isValidAccount(accountNo, customer)) {
					transactions=new Transaction();
					
					transactions.setTransactionId((int)transactionFn.generateAccountNo());
					
					System.out.println("1.Deposit");
					System.out.println("2.Withdrawal");
					System.out.println("Choose your option:");
					int option=scanner.nextInt();
					if(option==1)
						transactions.setTransactionType("credit");
					else if(option==2)
						transactions.setTransactionType("debit");
					else {
						System.out.println("Sorry! invalid option!");
						System.exit(0);
					}
					
					Account account=tx.findAccount(accountNo, customer);
					transactions.setAccount(account);
					transactions.setTransactionDate(LocalDate.now());
					
					System.out.println("Enter amount to deposit:");
					transactions.setAmount(scanner.nextDouble());
					transaction[index]=transactions;
					index++;
					
				}
				}else if(choice==3) {
					
					printTransactionSummary(transaction);
					
				}
				else if(choice==4)
				{
					printCurrentBAl(transaction,customer);
				
				
				}
			
				else 
				{
					
					System.out.println("Sorry! INvalid choice. Please try Again!");
				}
			
			
				
			}	
		
		
		
		else 
				{
					System.out.println("Invalid Customer Number! Please try.");
				}
			System.out.println("Would you like to continue[y|n]?");
			myChoice=scanner.next().charAt(0);
		}while(myChoice=='y'||myChoice=='Y');
	}
			
		
	
		
	
}
