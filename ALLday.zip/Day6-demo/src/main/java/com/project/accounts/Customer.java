package com.project.accounts;

import java.util.Arrays;

public class Customer {

	private int customerId;
	private String name;
	private Address address;
	

	private Account[] account=new Account[4];
	private String mobNo;
	private String emailId;
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", address=" + address + ", account="
				+ Arrays.toString(account) + ", mobNo=" + mobNo + ", emailId=" + emailId + "]";
	}
	
	public Customer(int custId, String name, Address address, Account[] account, String mobNo, String emailId) {
		super();
		this.customerId = custId;
		this.name = name;
		this.address = address;
		this.account = account;
		this.mobNo = mobNo;
		this.emailId = emailId;
	}

	public int getCustId() {
		return customerId;
	}

	public void setCustId(int custId) {
		this.customerId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Account[] getAccount() {
		return account;
	}

	public void setAccount(Account[] account) {
		this.account = account;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}
