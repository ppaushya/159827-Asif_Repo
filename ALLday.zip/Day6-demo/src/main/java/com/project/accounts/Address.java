package com.project.accounts;

public class Address {

	private	String stName;
	private	String addLine;
	private	String city;
	private	String state;

	
	
	


	public Address(String stName, String addLine, String city, String state) {
		super();
		this.stName = stName;
		this.addLine = addLine;
		this.city = city;
		this.state = state;
	}


	@Override
	public String toString() {
		return "Address [stName=" + stName + ", city=" + city + ", state=" + state + "]";
	}


	public String getStName() {
		return stName;
	}


	public void setStName(String stName) {
		this.stName = stName;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getAddLine() {
		return addLine;
	}


	public void setAddLine(String addLine) {
		this.addLine = addLine;
	}




}
