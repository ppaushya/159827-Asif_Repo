package com.project.accounts;

public enum accountType {
	SAVING,CURRENT,FD,RD;

}
