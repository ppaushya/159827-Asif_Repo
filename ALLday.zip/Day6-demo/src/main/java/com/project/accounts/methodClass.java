package com.project.accounts;

public class methodClass {
	
	public void init(Customer[] cust)
	{
		//cust[0]=new Customer();
	}

	public void getAddress()
	{
		System.out.println("Enter the Address:");
		System.out.println("Street Name:");
		System.out.println("City:");
		
	}
	
	public void getCust()
	{
		
	}
	
	public void getAcc()
	{
		
	}
	
	
	
	public static void main(String[] args) {

	}

}
