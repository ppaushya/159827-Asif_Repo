import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate now=LocalDate.now();
		
		LocalTime.ofInstant(Instant.now(), ZoneId.of("Pacific/Majuro"));
		
		java.util.Set<String> zones=ZoneId.getAvailableZoneIds();
		
	//	System.out.println(x);
		
		
		//Instant & Date
		Instant instant=Instant.now();
		
		Date date=Date.from(instant);
		Instant isntant=date.toInstant();
		
		
		//Instant & timeStamp
		
		Instant instant=Instant.now();
		TimeStamp time=Timestamp.from(instant);				//legacy -> new API
		Instant instant2=time.toInstant();					//API->legacy
		
		//LocalDate & Date
		
		Date date2=Date.from(localDate);
		LocalDate localdate=date.toLocalDate();
		
	//
		Date date=n
				Date d =new Date(localDate.toE)
		
		
	}

}
