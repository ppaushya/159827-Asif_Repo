import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;

public class java8DateDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Instant instnt=Instant.now();
		/*
		System.out.println(instnt);
		System.out.println(instnt.MIN);
		System.out.println(instnt.MAX);
		System.out.println(instnt.EPOCH);*/

		//Duration.between(startInclusive, endExclusive)
	
		LocalDate dats=LocalDate.now();
		System.out.println(dats);
		
		LocalTime time=LocalTime.now();
		System.out.println(time);
		
		LocalDate dats2=LocalDate.of(2001,1,3);
		Period period=Period.between(dats2,dats);
		System.out.println(period.getMonths());
		System.out.println(dats2);
		System.out.println(period.getDays());



		
		
		
	}

}
