import java.util.Calendar;
import java.util.GregorianCalendar;
public class testCalender {

	public static void main(String[] args) {
		Calendar cal=new GregorianCalendar();
		
		System.out.println(cal);
		System.out.println(cal.get(cal.DAY_OF_MONTH));
		System.out.println(cal.get(cal.DAY_OF_YEAR));
		//System.out.println(cal.THURSDAY);
		
		
		
	}
}
