
public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer buffer=new StringBuffer("Tom");
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
		
		
		buffer.repalce(0,3,"jerry");
	}

}

asuSystem.out.println("");

