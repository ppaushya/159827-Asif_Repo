package org.cap.sample;

public class regularClass_demo {

	int num=10;
	

		
		class InnerClass
		{
			String address;
			public void show()
			{
				System.out.println(address);
				System.out.println(num);
				
			}
		}
	

}
