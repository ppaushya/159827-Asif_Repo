package org.cap.sample;

public class regular_main {

	public static void main(String[] args) {
		
		regularClass_demo.InnerClass obj=new regularClass_demo().new InnerClass();

	}
}
