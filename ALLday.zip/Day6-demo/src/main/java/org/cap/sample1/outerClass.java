package org.cap.sample1;

import org.cap.sample.regularClass_demo;

public class outerClass {

	String str="jerry";
	
	public void details()
	{
		int count=100;
			class temp
			{
				int num=45;
				String str="Jack";
				
				public void print()
				{
					outerClass obj =new outerClass();
					
					System.out.print("Num:"+num);
					System.out.print("Name:"+str);
					System.out.print("Name:"+obj.str);
				}
			}
	}
	
public static void main(String[] args) {
		
	outerClass obj =new outerClass();

	obj.print();
	}
}
