package org.cap.demo;

public class Calculate {
	
	
	public int addNumber(int num1,int  num2) {
		return num1+num2;
	}
	
	
	public void runLoop() {
		long sum=0;
		for(long i=0;i<123;i++)
			sum+=i;
		System.out.println(sum);
	}

}
