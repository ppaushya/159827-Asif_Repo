import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Collections;

public class Main_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		ArrayList<employee> set=new ArrayList();
		
		//employee emp1=new employee(201,"abc","565879","as@gf",LocalDate.now());
		//employee emp2=new employee(201,"abc","565879","as@gf",LocalDate.now());
		//employee emp3=new employee(201,"abc","565879","as@gf",LocalDate.now());
		//employee emp4=new employee(201,"abc","565879","as@gf",LocalDate.now());
		
		set.add(new employee(2601,"abc","76","456@gf",LocalDate.now()));
		set.add(new employee(2022,"dfg","345","gh@gf",LocalDate.now()));
		set.add(new employee(203,"abfgc","45","gfgh@gf",LocalDate.now()));
		set.add(new employee(204,"dabc","676","gf@gf",LocalDate.now()));
		
		java.util.Collections.sort(set);
		
		Iterator<employee> iterator=set.iterator();
		while(iterator.hasNext())
		{
			//employee emp=iterator.next();
			System.out.println(iterator.next());
		}
		System.out.println();
		
		
	}

}
