import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Hashtable;;
import java.util.Set;
import java.util.Vector;

public class mapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Map<Integer,String> map=new HashMap<>();
		
		Hashtable<Integer,String> map=new Hashtable<>();

		map.put(143,"one");
		
		
		map.put(4,"four");
		map.put(556,"five");
		map.put(2,"two");
		map.put(556,"five");
		map.put(5,"five");
		map.put(45343,"three");
		map.put(643,"three");
		map.put(993,"three");

		map.put(65343,"three");

		
		
		//System.out.println(map);
		
		Set<Integer> ab=map.keySet();
		
		/*Iterator<Integer> iterator=ab.iterator();
		
		while(iterator.hasNext())
		{
			//employee emp=iterator.next();
			System.out.println(iterator.next());
		}
		System.out.println();
		
		*/
		
		Enumeration<Integer> en=map.elements();
	}

}
