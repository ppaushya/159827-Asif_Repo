import java.time.LocalDate;

public class employee implements Comparable<employee>{
	
	private int epmloyeeId;
	private String employeeName;
	private String phoneNo;
	private String email;
	private LocalDate date;
	

	

	
	public employee(int epmloyeeId, String employeeName, String phoneNo, String email, LocalDate date) {
		super();
		this.epmloyeeId = epmloyeeId;
		this.employeeName = employeeName;
		this.phoneNo = phoneNo;
		this.email = email;
		this.date = date;
	}

	public int getEpmloyeeId() {
		return epmloyeeId;
	}

	public void setEpmloyeeId(int epmloyeeId) {
		this.epmloyeeId = epmloyeeId;
	}

	@Override
	public String toString() {
		return "employee [epmloyeeId=" + epmloyeeId + ", employeeName=" + employeeName + ", phoneNo=" + phoneNo
				+ ", email=" + email + ", date=" + date + "]";
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public int compareTo(employee emp) {
		/*if(this.epmloyeeId<emp.epmloyeeId)
		{
			return 1;
		}
		else if(this.epmloyeeId>emp.epmloyeeId)
			return -1;
		else
		
		return 0;*/
		
		
		
		if(this.employeeName.compareTo(emp.employeeName)>0)
		{
			
			return 1;
		}
		else if(this.employeeName.compareTo(emp.employeeName)<0)
		{
			return -1;
		}
			
		else
			
			return 0;
			
	}

	
}
