import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetContainer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*LinkedHashSet<Integer> ab=new LinkedHashSet();
		
		ab.add(2);
		ab.add(3);
		ab.add(8);
		ab.add(null);
		ab.add(3);
		ab.add(5);
		ab.add(null);
		ab.add(6);
		
		System.out.println(ab);*/
		
		TreeSet<Integer> ab=new TreeSet();
		
		ab.add(2);
		ab.add(3);
		ab.add(8);
		//ab.add(null);
		ab.add(3);
		ab.add(5);
		//ab.add(null);
		ab.add(6);
		
		System.out.println(ab);
		
		
		
	}

}
