
public class Address {

	private String add1;
	private String addr;
	private String city;
	private String state;
	
	@Override
	public String toString() {
		return "Address [add1=" + add1 + ", addr=" + addr + ", city=" + city + ", state=" + state + "]";
	}

	public Address()
	{
		
	}
	
	public Address(String add1, String addr, String city, String state) {
		super();
		this.add1 = add1;
		this.addr = addr;
		this.city = city;
		this.state = state;
	}

	public String getAdd1() {
		return add1;
	}

	public void setAdd1(String add1) {
		this.add1 = add1;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
