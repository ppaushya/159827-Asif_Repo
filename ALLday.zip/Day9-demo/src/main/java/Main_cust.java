import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Main_cust {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Customer customer=new Customer();
		//Address address=new Address();
		TreeMap<Customer,Address> map=new TreeMap();
		
		map.put(new Customer(101,"abc"), new Address("stg","tasdg","Tn","We"));
		map.put(new Customer(102,"bca"), new Address("tsg","astdg","Tn","We"));
		map.put(new Customer(102,"bca"), new Address("sdg","uiatsdg","Tn","We"));
		map.put(new Customer(104,"efg"), new Address("sssg","uiasdg","Tn","We"));
		map.put(new Customer(105,"gfa"), new Address("jsg","uiasdg","Tn","We"));
		
		Set<Customer> ab=map.keySet();
			
		Iterator<Customer> iterator=ab.iterator();
		while(iterator.hasNext())
			
		{
			//employee emp=iterator.next();
			Customer abs=iterator.next();
			System.out.println(abs+" "+map.get(abs));
		}
		System.out.println();
		
		
		
	}

}
