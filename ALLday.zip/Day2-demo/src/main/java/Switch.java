import java.util.Scanner;

public class Switch {
	public void switchCase(String ch)
	{
		

		switch(ch)
		{
			case "yes":
			System.out.println("Hurrah!!!");break;
		
			case "no":
			System.out.println("Shittt!!!");break;
			
			default:
				System.out.println("Waiting!!!");break;
		}
	}
	
		
		public static void main(String[] args) {
		// TODO Auto-generated method stub
		Switch obj=new Switch();
		String ch;
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.print("Hey Dude you coming for PARTY? ");
		ch=scanner.next();
		
		obj.switchCase(ch);
	
	}

}
