
public class sumEven {

	public int sum(int num)
	{
		int sum=0;
		for(int i=0;i<=num;i+=2)
		{
			sum+=i;
		}
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*sumEven obj=new sumEven();
		
		int sum1=obj.sum(10);
		int sum2=obj.sum(20);
		int sum3=obj.sum(30);
		int sum4=obj.sum(40);
		
		System.out.println("Sum of Even upto 10 :"+sum1);
		System.out.println("Sum of Even upto 20 :"+sum2);
		System.out.println("Sum of Even upto 30 :"+sum3);
		System.out.println("Sum of Even upto 40 :"+sum4);
		*/
		
		/*
		int num=1;
		int count=5;
		
		while(num<100)
		{
			while(count>0)
			{
				if(num%2==0)
				{
					System.out.print(num+",");
					count--;
					
				}
				num++;
				
				
				
			}
			if(count==0)
			{count=5; System.out.println();}
		}
		*/
		int num=1;
		int count=5;
		int ch=5;
		
		while(num<100)
		{
			while(count>0)
			{
				if(num%2==0)
				{	if(count==ch)
						System.out.print(num);
					else	
						System.out.print(" * ");
					count--;
					
				}
				num++;
				
				
				
			}
			if(count==0)
			{
				count=5; 
				System.out.println();
				ch--;
			}
			if(ch==0)
				ch=5;
		}
		
	}

}
