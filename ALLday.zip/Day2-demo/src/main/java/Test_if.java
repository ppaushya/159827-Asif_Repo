
import java.util.Random;

public class Test_if {

	public void testif()
	{
		Random rand = new Random();
		double m=Math.random()*100;
		int  n = rand.nextInt(100-50+1) + 50;	
		if( m<50)
		{
			System.out.println("Hurrah!!!");
		}
		else
			System.out.println("Shittt!!!");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test_if obj=new Test_if();
		obj.testif();
	}

}
