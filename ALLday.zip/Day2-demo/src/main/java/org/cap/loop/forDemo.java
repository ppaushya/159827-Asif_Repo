package org.cap.loop;

public class forDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int i;
		for(i=1;i<10;i++)
		System.out.println(i);
		
	
}
}
