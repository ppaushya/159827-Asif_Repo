package org.demo;

import java.util.Scanner;

public class array2 {

	int[] arr;
	public void getElement(int size)
	{
		Scanner scan=new Scanner(System.in);
		arr=new int[size];
		
		System.out.println("ENter :");
		for(int i=0;i<size;i++)
		{
			arr[i]=scan.nextInt();
		}
	
		scan.close();
	}
	
	public void print()
	{	int size=arr.length;
		for(int i=0;i<size;i++)
		{
			System.out.println(arr[i]);
		}
		System.out.println("Size:"+size);
	}
	
	public void rev()
	{
		int size=arr.length;
		int a;
	
		for(int i=0;i<size;i++)
		{
			a=arr[size-1-i];
			arr[size-i-1]=arr[i];
			arr[i]=a;
			
		}
		
		for(int i=0;i<size;i++)
		{
			System.out.println(arr[i]);
		}
		
	}
	
	public void sort()
	{
		int a=0;
		int size=arr.length;
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				
				if(arr[i]>arr[j])
				{
					a=arr[i];
					arr[i]=arr[j];
					arr[j+1]=a;
				}arr[j+1]=a;
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		array2 obj=new array2();
		
		obj.getElement(5);
		obj.print();
		obj.rev();
		//obj.sort();
	}

}
