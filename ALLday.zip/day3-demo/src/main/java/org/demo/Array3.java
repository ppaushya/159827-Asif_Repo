package org.demo;

import java.util.Scanner;

public class Array3 {

	int[] arr=new int[5];
	
	public void getElement(int size)
	{
		Scanner scan=new Scanner(System.in);
	
		
		System.out.println("ENter :");
		for(int i=0;i<size;i++)
		{
			arr[i]=scan.nextInt();
		}
	
		scan.close();
	}
	
	public int biggest()
	{
		int big=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>big)
				big=arr[i];
		}
		return big;
	}
	
	public int smallest()
	{
		int small=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]<small)
				small=arr[i];
		}
		return small;
	}
	
	public int evenSum()
	{
		System.out.println("Even Elements");
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			
			if(arr[i]%2==0)
			{	sum+=arr[i];
				System.out.print(arr[i]+" ");
			}
		}
		return sum;
	}
	
	public void minMissing(int num)
	{
		//sorting
		for(int i=0;i<num;i++)
		{
			for(int j=i+1;j<num;j++)
			{
				if(arr[i]>arr[j])
				{
					int a=arr[i];
					arr[i]=arr[j];
					arr[j]=a;
				}
			}
		}
		//printing sorted data
		System.out.print("After Sorting: ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		//searching between elements
		int count=0;
		for(int i=0;i<arr.length-1;i++)
		{
			
			if(arr[i+1]-arr[i]>1)
			{
				count=1;
				System.out.println(arr[i]+1);
				break;
			}
			
			else 
				System.out.println(arr[arr.length-1]+1);
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Array3 obj=new Array3();
		obj.getElement(5);
		//System.out.println("\nBiggest:"+obj.biggest());
		//System.out.println("Smallest:"+obj.smallest());
		//System.out.println("\nSum of Even:"+obj.evenSum());
		obj.minMissing(5);
		
	}

}
