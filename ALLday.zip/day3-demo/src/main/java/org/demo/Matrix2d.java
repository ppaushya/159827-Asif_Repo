package org.demo;

import java.util.Scanner;

public class Matrix2d {
	
		static int row;
		static int col;
		int[][] arr;
		Scanner scan=new Scanner(System.in);
	
	public void get(int row,int col)
	{
		arr=new int[row][col];
		System.out.println("Enter the matrix:");
		
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				arr[i][j]=scan.nextInt();
		}
	}
	
	public void print()
	{
		System.out.println("Matrix:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				System.out.print(arr[i][j]+" ");
			System.out.println();
		}
	}
	
	public void upperTri()
	{
		System.out.println("upper Triangle:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				{
				if(i>j || i==j)
					System.out.print(arr[i][j]+" ");
				else 
					System.out.print(" ");
				}
				System.out.println();
		}
	}
	
	public void lowerTri()
	{
		System.out.println("Lower Triangle:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				{
				if(i<j || i==j)
					System.out.print(arr[i][j]+" ");
				else 
					System.out.print(" ");
				}
				System.out.println();
		}
	}
	
	public void trnspose()
	{
		System.out.println("Transpose:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				System.out.print(arr[j][i]+" ");
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Matrix2d obj=new Matrix2d();
		Scanner scan=new Scanner(System.in);
		
		System.out.println("No. of rows and col:");
		row=scan.nextInt();
		col=scan.nextInt();
		
		if(row!=col)
			System.out.println("No of rows not equal to col...!!!");
		else
		{
		obj.get(row,col);
		obj.print();
		obj.upperTri();
		obj.lowerTri();
		obj.trnspose();
		
		}
	}

}
