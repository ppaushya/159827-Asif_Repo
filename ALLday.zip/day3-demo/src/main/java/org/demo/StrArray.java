package org.demo;

import java.util.Scanner;

public class StrArray {

	String[] mystr;
	
	public void acceptString(int size)
	{
		Scanner scan=new Scanner(System.in);
		mystr=new String[size];
		
		System.out.println("Enter "+size+" Elemetns" );
		for(int i=0;i<size;i++)
		{
			mystr[i]=scan.next();
		}
	}
	
	public void printString()
	{
		System.out.println();
		for(int i=0;i<mystr.length;i++)
		{
			System.out.print(mystr[i]+" ");
		}
	}
	
	public void revStr()
	{
		System.out.println();
		String a=null;
		for(int i=0;i<mystr.length/2;i++)
		{
			a=mystr[i];
			mystr[i]=mystr[mystr.length-1-i];
			mystr[mystr.length-1-i]=a;
		}
		for(int i=0;i<mystr.length;i++)
		{
			System.out.print(mystr[i]+" ");
		}
	}
	
	public void sortString()
	{
		for(int i=0;i<mystr.length;i++)
		{
			for(int j=i+1;j<mystr.length;j++)
			{
				if(mystr[i].compareTo(mystr[j])>0)
				{
					String a=mystr[i];
					mystr[i]=mystr[j];
					mystr[j]=a;
				}
			}
		}
		
		//print
		System.out.println();
		for(int i=0;i<mystr.length;i++)
		{
			System.out.print(mystr[i]+" ");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StrArray obj=new StrArray();
		
		obj.acceptString(5);
		obj.printString();
		obj.revStr();
		obj.sortString();
	}

}
