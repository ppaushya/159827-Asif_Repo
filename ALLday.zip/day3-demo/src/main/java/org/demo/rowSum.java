package org.demo;

import java.util.Scanner;

public class rowSum {

	static int row;
	static int col;
	int[][] arr;

	Scanner scan=new Scanner(System.in);
	
	public void get(int row,int col)
	{
		arr=new int[row][col];
		System.out.println("Enter the matrix:");
		
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				arr[i][j]=scan.nextInt();
		}
	}
	
	public void print()
	{
		System.out.println("Matrix:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				System.out.print(arr[i][j]+" ");
			System.out.println();
		}
	}
	
	public void sumofRow()
	{
		
		int[] sum=new int[row];
		for(int i=0;i<row;i++)
		{
			
			for(int j=0;j<col;j++)
				{
				sum[i]+=arr[i][j];
								
				}
				
			
		}
		int small=sum[0];
		int flag=0;
		for(int i=0;i<row;i++)
		{
			if(sum[i]<small)
				flag=i;
		}
		for(int i=0;i<col;i++)
		{
			System.out.print(arr[flag][i]+" ");
		}
		
	
	}
	
	public void minMissing2d()
	{
		//sorting
		System.out.println("Sorting");
		for(int k=0;k<row;k++)
		{
			for(int i=0;i<col;i++)
			{
				for(int j=i+1;j<col;j++)
				{
					if(arr[k][i]>arr[k][j])
					{
						int a=arr[k][i];
						arr[k][i]=arr[k][j];
						arr[k][j]=a;
					}
				}
			}
		}
		print();
		
		//
	
		for(int k=0;k<row;k++)
		{
			for(int i=0;i<col;i++)
			{
			
				if(arr[k][i+1]-arr[k][i]>1)
				{
					
					System.out.println(arr[k][i]+1);
					break;
				}
			
			
			}
		}
		
	}
	
	public void addition()
	{
		int[][] resultMatrix = new int[row][col];
		int[][] arr2= {{2,3},{5,6},{8,4}};
		
		
        for (int i = 0; i < row; i++) {
               for (int j = 0; j < col; j++) {
                     resultMatrix[i][j] = arr[i][j] + arr2[i][j];
               }
        }
        
        System.out.println("Added Matrix:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
				System.out.print(resultMatrix[i][j]+" ");
			System.out.println();
		}
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		rowSum obj=new rowSum();
		rowSum obj1=new rowSum();
		Scanner scan=new Scanner(System.in);
		
		System.out.println("No. of rows and col:");
		row=scan.nextInt();
		col=scan.nextInt();
		
		obj.get(row,col);
		obj.print();
		obj.sumofRow();
		obj.minMissing2d();
		obj.addition();
		
	
		
	}

}
