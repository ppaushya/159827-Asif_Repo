package org.cap.demo;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;



public class ArrayListDemo {

	public static void main(String[] args) {


		LinkedList<String> lst=new LinkedList();
	//lst.ensureCapacity(15);
		
		lst.add("Tom");
		lst.add("dTom");
		lst.add("Tgom");
		lst.add(null);
		lst.add("fgfTom");
		lst.add("dfdTom");
		lst.add(null);
		lst.add("abh");
		
	//enahnced for loop
		
		for(String str:lst)
			System.out.print(str+",");
		
		System.out.println();
		
	//Iterator
		
		
		Iterator<String> iterator=lst.iterator();
		while(iterator.hasNext())
		{
			String str=iterator.next();
			System.out.print(str+",");
		}
		System.out.println();
		
		
		ArrayList<String> lst1=new ArrayList();
		lst1.add("s");
		lst1.add("o");
		lst1.add("k");
		
	//addAll
		lst1.addAll(lst);
		
	//clear all data
		//lst.clear();
		
	//List Iterator forward
	
		ListIterator<String> iterator1=lst.listIterator();
		while(iterator1.hasNext())
		{
			String str=iterator1.next();
			System.out.print(str+"-->");
		}
		System.out.println();
		
	//List Iterator backward
		
	
		//	ListIterator<String> iterator1=lst.listIterator();
			while(iterator1.hasPrevious())
			{
				String str=iterator1.previous();
				System.out.print("<--"+str);
			}
			System.out.println();
			
		//size()
			System.out.println(lst.size());
		//contains
			System.out.println(lst.contains("Tom"));
			System.out.println(lst.containsAll(lst1));
		
			
			System.out.println(lst.isEmpty());
		//to array
			Object[] arr=new Array[lst.size()];
			arr=lst.toArray();
			for(int i=0;i<lst.size();i++)
				System.out.print(arr[i]+"-");
			
			System.out.println();

			
		Object abc=lst.clone();
		System.out.print(abc);

		System.out.println();

		
		System.out.println(lst1.equals(lst));

		System.out.println(lst.indexOf("fgfTom"));
		
		System.out.println(lst.lastIndexOf("fgfTom"));
		
		//System.out.println(lst.listIterator(5));
		
		lst.remove("dTom");
		System.out.println(lst);
		lst.add(1, "dTom");
		System.out.println(lst);

		lst.remove(3);
		System.out.println(lst);
		lst.add(3, null);
		System.out.println(lst);

		

			
	}

}
