package org.cap.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CollectionDemo {

	public static void main(String[] args) {
		
		//ArrayList ls=new ArrayList();
		List<Integer> ls1=new ArrayList();
		
		//Collection lst=new ArrayList();
		//Iterable lst1=new ArrayList();
		
		ls1.add(3);
		ls1.add("tom");
		ls1.add(452.36);
		ls1.add(452.36);
		ls1.add(null);
		ls1.add(42569874L);
		ls1.add(new Object());
		ls1.add(null);
		
		System.out.println(ls1);
		System.out.println(ls1.get(3));
		
	}

}
