package org.cap.dao;

public class Main {
public static void main(String[] args) {
		
		TransactionDao dao=new TransactionDaoImpl();
		dao.performTransaction();
		
	}

}
