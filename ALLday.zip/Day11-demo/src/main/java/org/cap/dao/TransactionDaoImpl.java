package org.cap.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class TransactionDaoImpl implements TransactionDao {

	@Override
	public void performTransaction() {
		// TODO Auto-generated method stub
		
	}
	
	private InputStream getPath()
	{
		return this.getClass().getResourceAsStream("jdbc.properties");
	}

	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			
			Properties properties=new Properties();
			properties.load(getPath());
			//Class.forName("com.mysql.jdbc.Driver");
			Class.forName(properties.getProperty("driverClass"));
			
			//connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			connection=DriverManager.getConnection(properties.getProperty("url"), 
					properties.getProperty("user"), properties.getProperty("password"));
			return connection;
			
		}catch (SQLException | IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

}
