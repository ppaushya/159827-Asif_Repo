package org.cap.dao1;

import java.util.Properties;
import java.util.Set;

public class PropertiesDao {

	public static void main(String[] args) {


		Properties properties=new Properties();
		
		properties.put("firstNAme", "jack");
		properties.put("lastNAme", "HAri");
		properties.put("salary", "12000");
		
		properties.put(12, 45);
		
		Set keys=properties.keySet();
		for(Object key:keys)
		System.out.println(key+"-"+properties.get(key));

	}

}
