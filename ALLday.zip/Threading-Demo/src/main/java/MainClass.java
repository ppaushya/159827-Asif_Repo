import org.cap.thread.ThreadDemoRunnable;

public class MainClass {

	public static void main(String[] args) {

		/*MyThread th=new MyThread();
		MyThread th1=new MyThread();
		MyThread th2=new MyThread();
		
		MyThread th3=new MyThread("CAPGthread");
		
		
		th.start(); 	//Thread Started
		th1.start();
		th2.start();
		th3.start();*/
		
		
		ThreadDemoRunnable runnable=new ThreadDemoRunnable();
		
		Thread th=new Thread(runnable);
		Thread th1=new Thread(runnable);
		Thread th2=new Thread(runnable);
		
		
		th.start();
		
		/*try {
			th.join();										//th thread block other , perform to completer then only others work
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		th1.start();
		
		try {
		th1.join();										//th thread block other , perform to completer then only others work
		} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
	
		th2.start();
		}

}
