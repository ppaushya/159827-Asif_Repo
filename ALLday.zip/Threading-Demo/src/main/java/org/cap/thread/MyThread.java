package org.cap.thread;

public class MyThread extends Thread{
	
	int a;
	public MyThread()
	{
		
	}

	public MyThread(int a) {
		this.a=a;
		
		//setName(string);
	}

	@Override
	public synchronized void run()
	{
		
		for(int i=1;i<=10;i++)
		{
			/*try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		System.out.println(Thread.currentThread().getName()+"-->"+a+"x"+i+"="+a*i);
		}
	}

}
