package org.cap;

public class Consumer {
	

private int consumerId;
private String name;
}