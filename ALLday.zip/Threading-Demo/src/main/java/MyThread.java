
public class MyThread extends Thread{
	public MyThread()
	{
		
	}

	public MyThread(String string) {
		
		super(string);
		//setName(string);
	}

	@Override
	public void run()
	{
		System.out.println(getName()+" Thread Initiated!!");
		
	}
}
