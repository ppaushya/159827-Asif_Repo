package org.cap.demo;

public class Calculate {
	
	
	public int addNumber(int num1,int  num2) {
		return num1+num2;
	}

	public int addArray(Integer ... nums) {
		int sum=0;
		for(int num:nums)
			sum+=num;
		return sum;
	}

}
