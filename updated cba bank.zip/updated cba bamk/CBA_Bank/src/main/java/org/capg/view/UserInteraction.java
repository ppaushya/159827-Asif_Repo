package org.capg.view;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.service.CustomerServiceImpl;
import org.capg.util.Utility;

public class UserInteraction {

	Scanner scan=new Scanner(System.in);
	CustomerServiceImpl customerService=new CustomerServiceImpl();
	
	public int initialize()
	{
		System.out.println("\t\t\t***CBA BANKING WALLET ***\n");
		
		System.out.println("1. Create Customer");
		System.out.println("2. List Customer");
		System.out.println("3. Add Account");
		System.out.println("4. Perform Transactions");
		System.out.println("5. Transaction Summary");
		System.out.println("6. Exit");
		
		return scan.nextInt();
	}
	
	
	
	public Account getAccountDetails()
	{
		Account account=new Account();
		List<Customer> customers=customerService.getAllCustomers();
		
		System.out.println("Enter the cutomer number to add the account:");
		int customerId=scan.nextInt();
		
		
		if(Utility.isValidCustomerId(customers,customerId))
		{
			System.out.println("Valid Customer..");
			Customer customer=Utility.findCustomer(customerId,customers);
			
			if(customer!=null)
			{
			System.out.println("Enter the Account Details:" );
			System.out.println("--------------------------------------------");
			
			account.setAccountNumber((long)Utility.generateId());
			account.setAccountType(getAccountType());
			account.setOpeningDate(LocalDate.now());
			account.setOpeningBalance(getOpeningBalance());
			account.setDescription(getDescription());
			
			
			
			customerService.createAccount(account,customer);
			}
			
		}
		return account;
	}
	
	private String getDescription() {
		System.out.println("Description:");
		return scan.nextLine();
	}

	private double getOpeningBalance() {
		
		System.out.println("Enter Opening Balance:");
		
		return scan.nextDouble();
	}

	public AccountType getAccountType()
	{
		
	
		System.out.println("Account Type:");
		Utility.printAccountType();
		int option=scan.nextInt();
		
		switch(option) {
		case 1:
			return AccountType.SAVINGS;
		case 2:
			return AccountType.CURRENT;
		case 3:
			return AccountType.RD;
		case 4:
			return AccountType.FD;
		default:
			System.out.println("Invalid Account Type");
			System.exit(0);
		}
		
		return null;
	
	}
	
	public void printAllCustomers(List<Customer> customers)
	{

		System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
					+"\t"+ customer.getEmailId() + "\t\t" + customer.getMobileNo() );
		}
	}
	
	public Customer getCustomer()
	{
		Customer customer=new Customer();
		customer.setCustomerId(Utility.generateId());
		customer.setFirstName(getFname());
		customer.setLastName(getLname());
		customer.setEmailId(getEmail());
		customer.setMobileNo(getMobileNo());
		customer.setDateOfBirth(getDateOfBirth());
		
		customer.setAddress(getAddress(customer));
		
	
		
		return customer;
	}
	
	public Address getAddress(Customer customer)
	{
		Address address=new Address();
		
		System.out.println("Enter the Address Line1:");
		address.setAddressLine1(scan.next());
		
		System.out.println("Enter the Address Line2:");
		address.setAddressLine2(scan.next());
		
		System.out.println("Enter the City:");
		address.setCity(scan.next());
		
		System.out.println("Enter the State:");
		address.setState(scan.next());
		
		System.out.println("Enter the Pincode:");
		address.setPincode(scan.next());
		
		return address;
	}
	
	public String getFname()
	{
		boolean flag=false;
		String Fname;
		do
		{
		System.out.println("Enter the First Name:");
		Fname=scan.next();
		flag=Utility.isValidName(Fname);
		
		if(!flag)
		{
			System.out.println("-->Invalid First name!\n");
		}
		
		}while(!flag);
		
		
		return Fname;
		
	}
	
	public String getLname()
	{
		boolean flag=false;
		String Lname;
		do
		{
		System.out.println("Enter the Last Name:");
		Lname=scan.next();
		flag=Utility.isValidName(Lname);
		
		if(!flag)
		{
			System.out.println("-->Invalid Last name!\n");
		}
		
		}while(!flag);
		
		
		return Lname;
		
	}
	
	public String getEmail()
	{
		boolean flag=false;
		String email;
		do
		{
		System.out.println("Enter Email Id:");
		email=scan.next();
		
		if(email.matches("^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$"))
		{
			flag=true;
		}
		if(!flag)
			System.out.println("-->Invalid EmailId!");
		}while(!flag);
		
		
		return email;
	}
	
	public String getMobileNo()
	{
		String mob;
		boolean flag=false;
		
		do
		{
		System.out.println("Enter Phone Number:"); 
		mob=scan.next();
		
		if(mob.matches("^[0-9]{10}"))
		{
			flag=true;
		}
		if(!flag)
			System.out.println("-->Invalid Number!");
		}while(!flag);
		
		
		
		return mob;
	}
	
	public LocalDate getDateOfBirth()
	{
		boolean flag=false;
		String dob;
		Integer date,month,year;
		
		do {
		System.out.println("Enter the Date(dd-mm-yyy):");
		dob=scan.next();
		
		date=Integer.parseInt(dob.substring(0, 2));
		month=Integer.parseInt(dob.substring(3,5));
		year=Integer.parseInt(dob.substring(6, 10));
		
		if(date<1 || date>31 || dob.charAt(2)!='-' || dob.charAt(5)!='-' || month<1 || month>12)
		{
			flag=false;
		}
		else 
			flag=true;
		
		if(!flag)
			System.out.println("-->Invalid dateOfBirth Format!");
		}while(!flag);
		
		return LocalDate.of(year, month, date);
	}
	
	public String getPincode() {
		boolean flag=false;
		String pincode;
		do {
			System.out.println("Enter pincode:");
			pincode=scan.next();
			flag=Utility.isValidPincode(pincode);
			if(!flag)
				System.out.println("Please enter Valid pincode!");
		}while(!flag);
		
		return pincode;
	}

	
	
	
}
