package org.capg.util;

import java.util.List;

import org.capg.model.Customer;

public class Utility {
	
	
	public static int generateId()
	{
		return (int)(Math.random()*10000);
	}

	public static boolean isValidName(String name)
	{
		boolean flag=false;
		if(name.matches("[a-zA-Z]{3,}"))
		{
			flag=true;
		}
		
		return flag;
	}
	public static boolean isValidCustomerId(List<Customer> customers,int customerId)
	{
		boolean flag=false;
		for(Customer customer:customers)
			if(customer.getCustomerId()==customerId)
				flag=true;
		
		return flag;
		
	}
	
	public static Customer findCustomer(int customerId,List<Customer> customers)
	{
		
		for(Customer customer:customers)
			if(customerId==customer.getCustomerId())
			{
				return customer;
			}
		return null;
	}
	


	public static boolean isValidPincode(String pincode) {

		return pincode.matches("//d{6}");
	}

	public static void printAccountType() {

		AccountType[] types=AccountType.values();
		int count=0;
		for(AccountType type:types)
			System.out.println(++count + "." + type);
		
	}
	
}
