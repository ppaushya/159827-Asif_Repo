package assignments;

public class Student implements Q3_course{
	String name;
    int div;
    int mod;

    public Student(String name)
    {
        this.name=name;
    }

    public void division(int a)
    {
        div=a;
    }
    public void modules(int a)
    {
        mod=a;
    }
    public void display()
    {
        System.out.println("Name: "+name+" Division: "+div+" Modules: "+mod);
        
    }
}
