package assignments;

public interface Q2_Area {
	  
	    float calArea(float x);
}
