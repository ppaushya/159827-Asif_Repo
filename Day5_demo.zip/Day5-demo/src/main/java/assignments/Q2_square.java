package assignments;

public class Q2_square implements Q2_Area{
	 public float calArea(float a)
	    {
	        return a*a;
	    }
}
