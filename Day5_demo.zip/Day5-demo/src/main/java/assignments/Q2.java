package assignments;

/*
  Write a program in Java to show the usefulness of Interfaces as a place to
keep constant value of the program.
 */

public class Q2 {
	public static void main(String[] args)
    {
        Q2_Area sqr=new Q2_square();
      
        System.out.println("Area of Square= "+sqr.calArea(10));
        
    }
}
