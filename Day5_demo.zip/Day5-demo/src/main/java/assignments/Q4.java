package assignments;
import java.util.*;
/*
 Write a program in Java which implements interface Student which has
two methods Display_Grade and Attendance for PG_Students and UG_Students
(PG_Students and UG_Students are two different classes for Post Graduate and
Under Graduate students respectively).
 */

public class Q4 {

	public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        char grade;
        float attendance;
        grade=sc.next().charAt(0);
        attendance=sc.nextFloat();
        System.out.println("PG details: ");
        Q4_Student_interface pg=new Q4_PGStudent("Tom",grade,attendance);
        
        pg.displayGrade(grade);
        pg.displayattendance(attendance);
    
     System.out.println("UG details: ");
     Q4_Student_interface ug=new Q4_UGStudent("Jack",grade,attendance);
   ug.displayGrade(grade);
   ug.displayattendance(attendance);
     
    
    sc.close();
    }
    
}
