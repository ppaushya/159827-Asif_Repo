package assignments;

public class Q4_UGStudent implements Q4_Student_interface{
	String name;
    char grade;
       float attendance;
   public Q4_UGStudent(String name,char grade,float attendance)
   {
       this.name=name;
       System.out.println("Name: "+this.name);
   }
public void displayGrade(char grade)
{
   System.out.println("Grade: "+grade);
}
   public void displayattendance(float attendance)
{
   System.out.println("Attendance percent: "+attendance);
}
}
