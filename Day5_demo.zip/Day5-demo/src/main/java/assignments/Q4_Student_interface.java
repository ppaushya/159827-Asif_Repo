package assignments;

public interface Q4_Student_interface {

    public void displayGrade(char grade);
    public void displayattendance(float attendance);
    
    
}
