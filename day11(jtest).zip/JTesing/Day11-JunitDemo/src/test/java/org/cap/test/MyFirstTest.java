package org.cap.test;

import static org.junit.Assert.*;

import org.cap.demo.Calculate;
import org.junit.Test;

public class MyFirstTest {
	
	

	@Test
	public void test_addNumber_method() {
		Calculate calculate=new Calculate();
		assertEquals(15,calculate.addNumber(5, 10));
	}

}
