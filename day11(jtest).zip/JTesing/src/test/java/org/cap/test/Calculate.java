package org.cap.test;

public class Calculate {
	
	public int addNumber(int a, int b)
	{
		return a+b;
	}

}
