package org.cap.test;

public class Calculate {
	
	public int addNumber(int a, int b)
	{
		return a+b;
	}
	
	public int addArray(Integer[] nums)
	{
		int sum=0;
		for(int num:nums)
			sum+=num;
		return sum;
	}

}
