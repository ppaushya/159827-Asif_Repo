package org.cap.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.cap.demo.Calculate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class MyFirstTest {
	Calculate calculate=new Calculate();
	
	
	Integer[] input;
	Integer output;
	
	public MyFirstTest(Integer[] input,Integer output)
	{
		super();
		this.input=input;
		this.output=output;
	}
	
	@Parameters
	public static List<Object[]> getParms()
	{
		return Arrays.asList(new Object[][]
				{
				{new Integer[]{1,2,3,4},10},
				{new Integer[]{2,1,3,4},10},
				{new Integer[]{3,2,4,4},13},
				{new Integer[]{2,0,3,2},7}
				
				
				}
		);
	}

	@Test
	public void test_addNumber_method() {
	
		assertEquals(output.intValue(),calculate.addArray(input));
	}
	
	

}
