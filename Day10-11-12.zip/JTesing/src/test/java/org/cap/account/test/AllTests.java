package org.cap.account.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestAccount.class })		//list of test case classes in the suite

public class AllTests {

	
}
