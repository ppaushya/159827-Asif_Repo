package org.cap.account.model;

public class Address {
	
	private String addressline;
	
	public Address() {
		
	}

	public Address(String addressline) {
		super();
		this.addressline = addressline;
	}

	public String getAddressline() {
		return addressline;
	}

	public void setAddressline(String addressline) {
		this.addressline = addressline;
	}

	@Override
	public String toString() {
		return "Address [addressline=" + addressline + "]";
	}
	
	

}
