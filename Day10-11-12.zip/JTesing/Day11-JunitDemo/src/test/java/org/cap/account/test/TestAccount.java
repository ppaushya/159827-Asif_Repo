package org.cap.account.test;

import static org.junit.Assert.*;

import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.junit.Test;

public class TestAccount {

	/*@Test
	public void test_add_account() {
		IAccountService accountService=new AccountServiceImpl();
	}*/
	
	@Test(expected=IllegalArgumentException.class)
	public void when_createAccount_with_null_customer()
				throws InvalidAmountException {
		Customer customer=null;
		IAccountService accountService=new AccountServiceImpl();
		accountService.createAccount(customer, 3000);
	}

}











