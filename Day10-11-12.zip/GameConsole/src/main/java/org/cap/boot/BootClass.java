package org.cap.boot;

import org.cap.service.IRegistrationService;
import org.cap.service.RegistrationServiceImpl;
import org.cap.view.UserInteraction;

public class BootClass {
	IRegistrationService registrationService=new RegistrationServiceImpl();

	public static void main(String[] args) {
		registrationService.createRegistrationTable
		UserInteraction userInteraction=new UserInteraction();
		
		userInteraction.createCustomer();
		

	}

}
