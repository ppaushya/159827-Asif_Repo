package org.cap.service;

import org.cap.dao.IRegistrationDao;
import org.cap.dao.RegistrationDaoImpl;
import org.cap.model.Registration;

public class RegistrationServiceImpl implements IRegistrationService{
	
	IRegistrationDao registrationDao=new RegistrationDaoImpl();

	@Override
	public void createCustomer(Registration registration) {
		
		if(validRegistration(registration))
		{
			registrationDao.createCustomer(registration);
			
		}
		
		
	}

	private boolean validRegistration(Registration registration) {
		
		if(registration.getCustomerName().matches("[a-zA-Z]"))
			if(registration.getMobileNo().matches("[0-9]{8}"))
			return true;
		
		return false;
	}

}
