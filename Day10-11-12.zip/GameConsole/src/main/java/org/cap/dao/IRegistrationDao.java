package org.cap.dao;

import org.cap.model.Registration;

public interface IRegistrationDao {

	void createCustomer(Registration registration);

}
