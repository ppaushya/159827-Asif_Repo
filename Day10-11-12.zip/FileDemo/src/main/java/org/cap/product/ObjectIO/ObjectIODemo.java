package org.cap.product.ObjectIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.Scanner;

public class ObjectIODemo {
	static Scanner scan=new Scanner(System.in);

	public static void main(String[] args) {
		
		UI ui=new UI();
		
		
		File file=new File("D:\\Users\\muasif\\Desktop\\FileDemo\\product.txt");
		
		try(FileOutputStream out=new FileOutputStream(file))
		{
			boolean flag;
			String ch;
			ObjectOutputStream outStream=new ObjectOutputStream(out);
			do {
			Product product=ui.getProduct();
			//Product product1=new Product(1001,"Ankita",23,345.9,LocalDate.of(2011, 11, 23));
			
			if(product!=null)
			outStream.writeObject(product);
			
			System.out.println("Want to continue?[y/n]");
			ch=scan.next();
			}while(ch.charAt(0)=='y'||ch.charAt(0)=='Y');
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Reading form File
		
		try(FileInputStream in=new FileInputStream(file))
		{
			ObjectInputStream inStream=new ObjectInputStream(in);
			
			
			System.out.println(inStream.readObject());
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
