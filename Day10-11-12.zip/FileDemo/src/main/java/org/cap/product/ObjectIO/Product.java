package org.cap.product.ObjectIO;

import java.io.Serializable;
import java.time.LocalDate;

public class Product implements Serializable{

	private int productInt;
	private String productName;
	private int quantity;
	private double price;
	private LocalDate expiryDate;
	
	public Product()
	{
		
	}

	@Override
	public String toString() {
		return "Product [productInt=" + productInt + ", productName=" + productName + ", quantity=" + quantity
				+ ", price=" + price + ", expiryDate=" + expiryDate + "]";
	}

	public int getProductInt() {
		return productInt;
	}

	public void setProductInt(int productInt) {
		this.productInt = productInt;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Product(int productInt, String productName, int quantity, double price, LocalDate expiryDate) {
		super();
		this.productInt = productInt;
		this.productName = productName;
		this.quantity = quantity;
		this.price = price;
		this.expiryDate = expiryDate;
	}
	
	
}
