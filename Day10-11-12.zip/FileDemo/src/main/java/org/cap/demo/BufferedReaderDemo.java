package org.cap.demo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		File file =new File("D:\\Users\\muasif\\Desktop\\FileDemo\\fileDemo.txt");
		try(FileInputStream in=new FileInputStream(file)) 
		{
			
			//BufferedReader reader=new BufferedReader(in);
			
			
			BufferedInputStream inputStream=new BufferedInputStream(in);
			/*int line=inputStream.read();
			System.out.println((char)line);
			*/
			
			
			byte[] arr=new byte[100];
			
			inputStream.read(arr);
			
			for(byte c:arr)
				System.out.print((char)c);
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}
