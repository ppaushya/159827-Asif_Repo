package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class readPrintRev {

	public static void main(String[] args) {
		File file =new File("D:\\Users\\muasif\\Desktop\\FileDemo\\fileDemo.txt");
		int ch;
		char[] list = new char[22];
		try(FileReader reader=new FileReader(file);)
		{
			int i=0;
		
			do {
			ch=reader.read();
			list[i]=(char)ch;
			i++;
			}while(ch!=-1);
				
			
			for(i=list.length-1;i>=0;i--)
			System.out.println(list[i]);
			
		
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
