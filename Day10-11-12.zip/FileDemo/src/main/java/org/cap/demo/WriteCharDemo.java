package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharDemo {

	public static void main(String[] args) {
		String greetings="Good Morning";

		File file =new File("D:\\Users\\muasif\\Desktop\\FileDemo\\sample.txt");
		
		try(FileWriter write=new FileWriter(file);)
		{
			//char[] ch=greetings.toCharArray();
			
			//FileReader reader=new FileReader(file);
			
			/*for(char cha:ch)
				write.write(cha);*/
			
			write.write(greetings);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
