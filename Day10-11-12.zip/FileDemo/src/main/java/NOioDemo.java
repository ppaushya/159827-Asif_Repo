import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.ReadableByteChannel;

public class NOioDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		FileInputStream in;
		FileOutputStream out;
		
		try {
			
		in=new 
		ReadableByteChannel reader=in.getChannel();
		}
	}
		
}
