package org.capgemini.service;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/api")
public class RestService {
	
	@POST
	@Path("/hello")
	public String sayHello()
	{
		return "Hello Buddy";
	}
	
	@POST
	@Path("/greet/{username}")
	@Produces(MediaType.TEXT_HTML)
	public String greetUser(@PathParam("username") String user)
	{
		
		//return "hello "+user;
		
		return "<html>\r\n" + 
				"	<body>hello\"+user+\"</body></html>";
	
	
	}
	

}
