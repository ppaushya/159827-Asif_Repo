package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.Calculator")
public class CalculatorImpl implements Calculator{

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int addAnumber(int num1, int num2) {
		
		return num1+num2;
	}

}
