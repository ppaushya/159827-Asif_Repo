package com.capgemini;

import javax.xml.ws.Endpoint;

public class CalcualtorPublisher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Endpoint.publish("http://localhost:7700/ws/Calculator", new CalculatorImpl());

	}

}
